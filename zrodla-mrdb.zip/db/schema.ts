// Intentionally empty by default.
// Add Drizzle tables here when the site actually needs a database.
// See examples/d1/db/schema.ts for an opt-in example.
import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const records = sqliteTable('records', { id: text('id').primaryKey(), data: text('data').notNull(), version: integer('version').notNull().default(1) });
export const history = sqliteTable('history', { id: text('id').primaryKey(), data: text('data').notNull() });
export const authUsers = sqliteTable('auth_users', {id:text('id').primaryKey(),email:text('email').notNull().unique(),name:text('name').notNull(),password:text('password').notNull(),role:text('role').notNull(),active:integer('active').notNull().default(1),profile:text('profile').notNull().default('{}'),mustChange:integer('must_change').notNull().default(0)});
export const authSessions = sqliteTable('auth_sessions',{token:text('token').primaryKey(),userId:text('user_id').notNull(),expires:integer('expires').notNull()});
export const authLimits = sqliteTable('auth_limits',{key:text('key').primaryKey(),count:integer('count').notNull(),expires:integer('expires').notNull()});
export const appSettings = sqliteTable('app_settings',{id:text('id').primaryKey(),data:text('data').notNull(),version:integer('version').notNull().default(1)});
