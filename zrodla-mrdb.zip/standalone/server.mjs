import http from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {mkdir,readFile,writeFile,readdir,stat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {handleApi} from '../lib/mrdb-service.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
export async function createServer(options={}){
 const dataDir=path.resolve(options.dataDir||process.env.DATA_DIR||path.join(root,'data'));await mkdir(path.join(dataDir,'files'),{recursive:true});
 const db=new DatabaseSync(path.join(dataDir,'mrdb.sqlite'));db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS _migrations(name TEXT PRIMARY KEY)');
 const migrationDir=path.join(root,'../drizzle');for(const name of (await readdir(migrationDir)).filter(n=>n.endsWith('.sql')).sort()){if(!db.prepare('SELECT name FROM _migrations WHERE name=?').get(name)){db.exec('BEGIN IMMEDIATE');try{db.exec(await readFile(path.join(migrationDir,name),'utf8'));db.prepare('INSERT INTO _migrations(name) VALUES(?)').run(name);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}}}
 class Statement{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Statement(this.sql,args);}async first(){return db.prepare(this.sql).get(...this.args)||null;}async all(){return {results:db.prepare(this.sql).all(...this.args)};}async run(){const r=db.prepare(this.sql).run(...this.args);return {meta:{changes:Number(r.changes)}};}}
 const env={MRDB_SETUP_TOKEN:options.setupToken||process.env.MRDB_SETUP_TOKEN,DB:{prepare:sql=>new Statement(sql),atomic:async fn=>{db.exec('BEGIN IMMEDIATE');try{const result=await fn({...env.DB,batch:async statements=>{const result=[];for(const statement of statements)result.push(await statement.run());return result;}});db.exec('COMMIT');return result;}catch(e){db.exec('ROLLBACK');throw e;}},batch:async statements=>{db.exec('BEGIN IMMEDIATE');try{const result=[];for(const s of statements){const r=db.prepare(s.sql).run(...s.args);result.push({meta:{changes:Number(r.changes)}});}db.exec('COMMIT');return result;}catch(e){db.exec('ROLLBACK');throw e;}}},BUCKET:{put:async(key,buffer,meta)=>{if(!/^[a-f0-9-]{36}$/.test(key))throw Error('Invalid key');await writeFile(path.join(dataDir,'files',key),Buffer.from(buffer));await writeFile(path.join(dataDir,'files',key+'.json'),JSON.stringify(meta.customMetadata||{}));},get:async key=>{if(!/^[a-f0-9-]{36}$/.test(key))return null;try{return {body:await readFile(path.join(dataDir,'files',key)),customMetadata:JSON.parse(await readFile(path.join(dataDir,'files',key+'.json'),'utf8'))};}catch{return null;}}}};
 const publicDir=path.resolve(options.publicDir||path.join(root,'public')),origin=options.origin||process.env.PUBLIC_ORIGIN;
 const production=process.env.NODE_ENV==='production';if(production&&(!origin||!origin.startsWith('https://')))throw Error('Ustaw PUBLIC_ORIGIN na właściwy adres HTTPS.');
 let pendingApi=Promise.resolve();
 const runApi=req=>{const task=pendingApi.then(()=>handleApi(req,env));pendingApi=task.then(()=>{},()=>{});return task;};
 const server=http.createServer(async(input,output)=>{
  try{
   output.setHeader('X-Content-Type-Options','nosniff');output.setHeader('Referrer-Policy','same-origin');output.setHeader('X-Frame-Options','DENY');output.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; worker-src 'self' blob:; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
   if(production)output.setHeader('Strict-Transport-Security','max-age=31536000');
   const base=origin||`http://${input.headers.host}`,url=new URL(input.url,base);
   if(url.pathname.startsWith('/api/')){
    let size=0;const chunks=[];for await(const chunk of input){size+=chunk.length;if(size>11*1024*1024){output.writeHead(413);output.end('Za duży plik');return;}chunks.push(chunk);}
    const headers=new Headers();for(const [k,v]of Object.entries(input.headers))if(v)headers.set(k,Array.isArray(v)?v.join('; '):v);
    // Never trust a caller-supplied Cloudflare address on independent hosting.
    headers.set('cf-connecting-ip',input.socket.remoteAddress||'unknown');
    const req=new Request(url,{method:input.method,headers,...(!['GET','HEAD'].includes(input.method)?{body:Buffer.concat(chunks)}:{})});
    const response=await runApi(req);for(const [k,v]of response.headers)output.setHeader(k,v);output.writeHead(response.status);output.end(Buffer.from(await response.arrayBuffer()));return;
   }
   const relative=decodeURIComponent(url.pathname),target=path.resolve(publicDir,'.'+relative);if(target!==publicDir&&!target.startsWith(publicDir+path.sep)){output.writeHead(404);output.end();return;}
   let file=target;try{if(!(await stat(file)).isFile())file=path.join(publicDir,'index.html');}catch{file=path.join(publicDir,'index.html');}
   const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.woff2':'font/woff2','.png':'image/png','.webmanifest':'application/manifest+json'};output.setHeader('Content-Type',mime[path.extname(file)]||'application/octet-stream');output.setHeader('Cache-Control',['index.html','sw.js','manifest.webmanifest'].some(n=>file.endsWith(n))?'no-cache':'public, max-age=3600');output.end(await readFile(file));
  }catch(e){console.error(e.message);if(!output.headersSent)output.writeHead(500);output.end('Nie udało się obsłużyć żądania.');}
 });
 server.on('close',()=>db.close());return {server,db,env};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){const {server}=await createServer();const port=Number(process.env.PORT||3000),host=process.env.HOST||'127.0.0.1';server.listen(port,host,()=>console.log(`MRDB: http://${host}:${port}`));}
