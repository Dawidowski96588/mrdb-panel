import {mkdir,copyFile,readFile,writeFile,readdir,cp} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
const base=path.resolve('outputs/github-pages'),out=path.resolve('outputs/free-publish');await mkdir(out,{recursive:true});
const html=(await readFile(path.join(base,'index.html'),'utf8')).replaceAll('./assets/','./');await writeFile(path.join(out,'index.html'),html);
for(const name of await readdir(path.join(base,'assets')))await copyFile(path.join(base,'assets',name),path.join(out,name));
for(const name of await readdir(base)){if(!['index.html','assets','config.json','.nojekyll'].includes(name))await copyFile(path.join(base,name),path.join(out,name));}
await copyFile(path.join(base,'config.json'),path.join(out,'config.json'));await writeFile(path.join(out,'.nojekyll'),'');
await writeFile(path.join(out,'README.md'),'# MRDB — panel testowy\n\nDarmowe wdrożenie: GitHub Pages + Supabase Free.\n\nRepozytorium zawiera gotowy interfejs. Pełne źródła są w archiwum `zrodla-mrdb.zip`. Konta, rejestry i załączniki są przechowywane w chronionej bazie Supabase i nie trafiają do GitHuba.\n\nAdres panelu: https://dawidowski96588.github.io/mrdb-panel/\n\nAktualizacja: zbuduj źródła według `free-hosting/WDROZENIE.md`, a następnie zastąp pliki interfejsu. Dane pozostają w Supabase.\n');
const source=path.resolve('outputs/free-source-'+Date.now());await mkdir(source,{recursive:true});
for(const name of ['app','lib','free-hosting','public-pwa','drizzle','db'])await cp(name,path.join(source,name),{recursive:true});
await mkdir(path.join(source,'supabase'),{recursive:true});await cp('supabase/migrations',path.join(source,'supabase/migrations'),{recursive:true});await cp('supabase/functions',path.join(source,'supabase/functions'),{recursive:true});await copyFile('supabase/config.toml',path.join(source,'supabase/config.toml'));
await mkdir(path.join(source,'standalone'),{recursive:true});for(const name of ['server.mjs','security.test.mjs'])await copyFile('standalone/'+name,path.join(source,'standalone',name));
await mkdir(path.join(source,'.github/workflows'),{recursive:true});await copyFile('.github/workflows/pages.yml',path.join(source,'.github/workflows/pages.yml'));
for(const name of ['package.json','package-lock.json','postcss.config.mjs','tsconfig.json','.gitignore'])await copyFile(name,path.join(source,name));
const archive=path.join(out,'zrodla-mrdb.zip');const result=spawnSync('tar',['-a','-c','-f',archive,'-C',source,'.'],{stdio:'inherit'});if(result.status!==0)throw Error('Błąd pakowania źródeł.');
console.log(out);
