import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {randomBytes,createHash} from 'node:crypto';
import {PGlite} from '@electric-sql/pglite';
import {createDatabase} from './pg-adapter.mjs';
import {createEdgeHandler} from './edge-handler.mjs';
import {handleApi} from '../lib/mrdb-service.mjs';
test('GitHub Pages + PostgreSQL: logowanie, CORS, role, trwały zapis i prywatne pliki',async()=>{
 const pg=new PGlite();
 await pg.exec("CREATE ROLE anon;CREATE ROLE authenticated;CREATE SCHEMA storage;CREATE TABLE storage.buckets(id text PRIMARY KEY,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);");
 await pg.exec(await readFile(new URL('../supabase/migrations/202611080001_mrdb_free.sql',import.meta.url),'utf8'));
 const wrap=client=>({query:async(sql,args)=>{const r=await client.query(sql,args);return {rows:r.rows,rowCount:r.affectedRows??r.rows.length};},transaction:fn=>client.transaction(tx=>fn(wrap(tx)))});
 const DB=createDatabase(wrap(pg)),files=new Map(),origin='https://dawidowski96588.github.io',key=randomBytes(32).toString('hex'),password=randomBytes(20).toString('hex');
 const env={DB,MRDB_SETUP_HASH:createHash('sha256').update(key).digest('hex'),ALLOWED_ORIGINS:[origin],BUCKET:{put:async(k,data,meta)=>files.set(k,{body:data,customMetadata:meta.customMetadata}),get:async k=>files.get(k)}};
 const handler=createEdgeHandler(handleApi,env),endpoint='https://example.supabase.co/functions/v1/mrdb-api';
 async function call(route,data,token,extra={}){const response=await handler(new Request(endpoint+route,{method:data===undefined?'GET':'POST',headers:{Origin:origin,...(token?{Authorization:'Bearer '+token}:{}),...(data!==undefined?{'Content-Type':'application/json'}:{}),...extra},...(data!==undefined?{body:JSON.stringify(data)}:{})}));return {response,status:response.status,data:await response.json()};}
 try{
  const preflight=await handler(new Request(endpoint+'/api/records',{method:'OPTIONS',headers:{Origin:origin}}));assert.equal(preflight.status,204);assert.equal(preflight.headers.get('access-control-allow-origin'),origin);
  assert.equal((await call('/api/auth/session',undefined,undefined,{Origin:'https://obcy.example'})).status,403);
  assert.equal((await call('/api/records')).status,401);assert.equal((await call('/api/files?key=x')).status,401);
  assert.equal((await call('/api/auth/setup',{token:key,email:'chair@example.org',name:'Przewodniczący testów',password})).status,200);
  assert.equal((await call('/api/auth/setup',{token:key,email:'other@example.org',name:'Drugi',password})).status,409);
  const login=await call('/api/auth/login',{email:'chair@example.org',password});assert.equal(login.status,200);const token=login.data.sessionToken;assert.match(token,/^[a-f0-9]{64}$/);assert.equal(login.response.headers.has('set-cookie'),false);assert.equal(login.data.user.password,undefined);
  assert.equal((await call('/api/records',undefined,undefined,{Cookie:'mrdb_session='+token})).status,401);
  const record=(await call('/api/records',{record:{kind:'task',title:'Test PostgreSQL',status:'W toku'}},token)).data.record;
  assert.ok(record.id);const update=await call('/api/records',{record:{...record,status:'Zakończone'}},token);assert.equal(update.status,200);
  assert.equal((await call('/api/records',{record},token)).status,409);
  const state=(await call('/api/records',undefined,token)).data;assert.equal(state.records.length,1);assert.equal(state.records[0].status,'Zakończone');assert.ok(state.history.some(h=>h.before?.status==='W toku'&&h.after?.status==='Zakończone'));
  const settings=(await call('/api/settings',undefined,token)).data.settings;settings.theme='violet';const saved=await call('/api/settings',{settings},token);assert.equal(saved.status,200);assert.equal((await call('/api/settings',{settings},token)).status,409);
  const temporary=randomBytes(20).toString('hex'),own=randomBytes(20).toString('hex');assert.equal((await call('/api/users',{name:'Radny testów',email:'radny@example.org',role:'Radny / radna',password:temporary},token)).status,200);
  const first=(await call('/api/auth/login',{email:'radny@example.org',password:temporary})).data.sessionToken;
  assert.equal((await call('/api/records',undefined,first)).status,403);
  assert.equal((await call('/api/profile',{name:'Radny testów',email:'radny@example.org',currentPassword:temporary,password:own},first)).status,200);
  assert.equal((await call('/api/records',undefined,first)).status,401);
  const radny=(await call('/api/auth/login',{email:'radny@example.org',password:own})).data.sessionToken;
  assert.equal((await call('/api/records',undefined,radny)).status,200);assert.equal((await call('/api/users',undefined,radny)).status,403);assert.equal((await call('/api/settings',{settings},radny)).status,403);
  assert.equal((await call('/api/records',{record:{...update.data.record,owner:'Radny testów'}},radny)).status,403);
  for(const attempt of [{role:'Prezydium'},{committee:'Prezydium'},{committeeRole:'Przewodniczący komisji'}])assert.equal((await call('/api/profile',{name:'Radny testów',email:'radny@example.org',...attempt},radny)).status,403);
  assert.equal((await call('/api/committees',undefined,radny)).status,403);
  await call('/api/users',{name:'Prezydium testów',email:'prezydium@example.org',role:'Prezydium',password:temporary},token);
  const preFirst=(await call('/api/auth/login',{email:'prezydium@example.org',password:temporary})).data.sessionToken;
  await call('/api/profile',{name:'Prezydium testów',email:'prezydium@example.org',currentPassword:temporary,password:own},preFirst);
  const pre=(await call('/api/auth/login',{email:'prezydium@example.org',password:own})).data.sessionToken;
  const roster=(await call('/api/committees',undefined,pre)).data,member=roster.members.find(m=>m.name==='Radny testów'),committee=roster.committees[0];assert.ok(committee);
  const assignment={id:member.id,committee,position:'Przewodniczący komisji',expectedCommittee:member.committee,expectedPosition:member.position,expectedRole:member.role};
  assert.equal((await call('/api/committees',assignment,radny)).status,403);
  assert.equal((await call('/api/committees',{...assignment,role:'Prezydium'},pre)).status,403);
  assert.equal((await call('/api/committees',assignment,pre)).status,200);
  assert.equal((await call('/api/committees',assignment,pre)).status,409);
  assert.equal((await call('/api/auth/session',undefined,radny)).data.user.role,'Przewodniczący komisji');
  assert.equal((await call('/api/profile',{name:'Radny testów',email:'radny@example.org',bio:'Nowy opis'},radny)).status,200);
  const assigned=(await call('/api/auth/session',undefined,radny)).data.user;assert.equal(assigned.profile.committee,committee);assert.equal(assigned.profile.committeeRole,'Przewodniczący komisji');
  assert.equal((await call('/api/committees',undefined,radny)).status,403);
  assert.equal((await call('/api/users',{name:'Nieuprawniony',email:'x@example.org',role:'Prezydium',password:own},pre)).status,403);
  for(const organizer of ['Cała MRDB','Brak komisji',committee]){
   const created=await call('/api/records',{record:{kind:'event',title:'Spotkanie '+organizer,status:'Planowane',committee:organizer}},radny);assert.equal(created.status,200);
   assert.equal((await call('/api/records',{record:{...created.data.record,committee:'Prezydium'}},radny)).status,403);
  }
  assert.equal((await call('/api/records',{record:{kind:'event',title:'Obce prezydium',committee:'Prezydium'}},radny)).status,403);
  assert.equal((await call('/api/committees',{id:member.id,committee:'Brak komisji',position:'',expectedCommittee:committee,expectedPosition:'Przewodniczący komisji',expectedRole:'Przewodniczący komisji'},pre)).status,200);
  assert.equal((await call('/api/auth/session',undefined,radny)).data.user.role,'Radny / radna');
  const form=new FormData();form.append('file',new File(['Prywatny protokół'],'protokol.txt'));
  const upload=await handler(new Request(endpoint+'/api/files',{method:'POST',headers:{Origin:origin,Authorization:'Bearer '+token},body:form}));assert.equal(upload.status,200);const file=await upload.json();
  const download=await handler(new Request(endpoint+'/api/files?key='+file.key,{headers:{Origin:origin,Authorization:'Bearer '+radny}}));assert.equal(await download.text(),'Prywatny protokół');assert.match(download.headers.get('content-disposition'),/attachment/);
  assert.equal((await call('/api/files?key='+file.key)).status,401);
  // Failed transactions cannot leave half-saved records or history.
  await assert.rejects(DB.batch([DB.prepare('INSERT INTO records(id,data,version) VALUES(?,?,?)').bind('rollback','{}',1),DB.prepare('INSERT INTO records(id,data,version) VALUES(?,?,?)').bind(record.id,'{}',1)]));assert.equal(await DB.prepare('SELECT id FROM records WHERE id=?').bind('rollback').first(),null);
  await pg.exec('SET ROLE anon');await assert.rejects(pg.query('SELECT * FROM mrdb.auth_users'),/permission denied/i);await pg.exec('RESET ROLE');
  assert.equal((await call('/api/auth/logout',{},token)).status,200);assert.equal((await call('/api/records',undefined,token)).status,401);
 }finally{await pg.close();}
});
