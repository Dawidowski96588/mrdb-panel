import assert from 'node:assert/strict';
import {projectionView} from '../lib/session-board.mjs';
export async function checkSessionBoard(call,manager,radny,eventId,upload){
 const get=(token=manager)=>call('/api/sessions?eventId='+eventId,undefined,token);
 assert.equal((await get()).data.board,null);assert.equal((await call('/api/sessions',{eventId,action:'init'},radny)).status,403);
 let r=await call('/api/sessions',{eventId,action:'init'},manager);assert.equal(r.status,200);let board=r.data.board;
 async function act(action,data={},expected=200){const r=await call('/api/sessions',{eventId,version:board.version,action,...data},manager);assert.equal(r.status,expected,JSON.stringify(r.data));if(r.status===200)board=r.data.board;return r;}
 await act('init',{},409);await act('agendaSave',{title:'Otwarcie sesji'});const first=board.agenda[0].id;await act('agendaSave',{title:'Podjęcie uchwały'});const second=board.agenda[1].id;
 await act('agendaMove',{id:second,direction:'up'});assert.equal(board.agenda[0].id,second);await act('agendaCurrent',{id:second});assert.equal(board.display.mode,'agenda');
 await act('resolutionSave',{number:'I/1/2026',title:'Uchwała testowa',body:'§ 1. Rada przyjmuje plan warsztatów.\n§ 2. Uchwała wchodzi w życie.',agendaId:second});const resolution=board.resolutions[0];
 await act('resolutionSave',{number:resolution.number,title:'Powtórzony numer',body:'Treść',agendaId:second},400);
 let doc=(await call('/api/records',undefined,manager)).data.records.find(r=>r.id===resolution.documentId);assert.equal(doc.type,'Uchwała');assert.equal(doc.description,resolution.body);
 if(upload){
  const uploadResponse=await upload(manager,new File(['<html>blocked</html>'],'fake.pdf',{type:'application/pdf'}));assert.equal(uploadResponse.status,400);
  const uploaded=await upload(manager,new File(['%PDF-1.7\nfixture'],'uchwala.pdf',{type:'application/pdf'}));assert.equal(uploaded.status,200);const attachment=uploaded.data.attachment;
  assert.equal((await upload(radny,new File(['%PDF-1.7\nfixture'],'uchwala.pdf',{type:'application/pdf'}))).status,403);
  await act('resolutionSave',{...resolution,attachment:{...attachment,pages:100,name:'fałszywa nazwa'}});assert.equal(board.resolutions[0].attachment.pages,2);assert.equal(board.resolutions[0].attachment.name,'uchwala.pdf');
  const denied=await call('/api/files?key='+attachment.key,undefined,radny);assert.equal(denied.status,403);
  await act('resolutionSave',{...resolution,attachment:{key:'invalid'}},400);
  await act('display',{mode:'resolution',resolutionId:resolution.id,page:1,zoom:2,position:'bottom'});let projected=projectionView(board,null,{title:'MRDB',shortName:'MRDB'});assert.equal(projected.resolution.page,2);assert.equal(projected.resolution.zoom,2);assert.equal(projected.resolution.position,'bottom');assert.equal(projected.resolution.attachment.key,attachment.key);
  await act('display',{mode:'resolution',resolutionId:resolution.id,page:2},400);await act('display',{mode:'resolution',resolutionId:resolution.id,page:0,zoom:10},400);
 }
 await act('display',{mode:'resolution',resolutionId:resolution.id,page:99},400);await act('display',{mode:'resolution',resolutionId:resolution.id,page:0});
 await act('votePrepare',{resolutionId:resolution.id});let vote=board.votes.at(-1);assert.equal(vote.state,'pending');assert.equal(board.display.mode,'vote');
 await act('votePrepare',{title:'Drugi',agendaId:first},400);
 await act('resolutionSave',{...resolution,title:'Zmiana po otwarciu głosowania'},400);
 await act('votePublish',{id:vote.id,yes:-1,no:0,abstain:0},400);await act('votePublish',{id:vote.id,yes:0,no:0,abstain:0},400);await act('votePublish',{id:vote.id,yes:1.5,no:0,abstain:0},400);
 await act('votePublish',{id:vote.id,yes:2,no:0,abstain:0},400); // More votes than the attendance snapshot needs an explanation.
 const staleVersion=board.version;await act('votePublish',{id:vote.id,yes:1,no:0,abstain:0,outcome:'Odrzucono'});vote=board.votes.at(-1);assert.equal(vote.outcome,'Przyjęto');assert.equal(vote.unanimous,true);assert.equal(board.display.mode,'result');
 assert.equal((await call('/api/sessions',{eventId,version:staleVersion,action:'display',mode:'blank'},manager)).status,409);
 await act('voteCorrect',{id:vote.id,yes:0,no:1,abstain:0},400);await act('voteCorrect',{id:vote.id,yes:0,no:1,abstain:0,reason:'PRYWATNY POWÓD KOREKTY'});const corrected=board.votes.at(-1);assert.equal(corrected.outcome,'Odrzucono');assert.equal(corrected.unanimous,true);assert.equal(board.votes[0].state,'superseded');
 const blocked=await get(radny);assert.equal(blocked.status,403);assert.equal(blocked.data.board,undefined);
 const projected=projectionView(board,{inside:1,total:2,unmarked:0},{title:'MRDB',shortName:'MRDB'});assert.equal(projected.vote.outcome,'Odrzucono');assert.equal(projected.vote.no,1);assert.equal(projected.vote.unanimous,true);assert.equal(projected.vote.reason,undefined);assert.equal(projected.vote.actor,undefined);assert.equal(JSON.stringify(projected).includes('PRYWATNY POWÓD KOREKTY'),false);
 doc=(await call('/api/records',undefined,radny)).data.records.find(r=>r.id===resolution.documentId);assert.equal(doc.resolutionOutcome,'Odrzucono');assert.equal(doc.voteResults.no,1);
 await act('agendaRemove',{id:second},400);await act('votePrepare',{title:'Przyjęcie porządku obrad',agendaId:first});const tied=board.votes.at(-1);await act('votePublish',{id:tied.id,yes:1,no:1,abstain:0,countNote:'Doprecyzowano listę obecności'});assert.equal(board.votes.at(-1).outcome,'Odrzucono');assert.equal(board.votes.at(-1).unanimous,false);
 await act('votePrepare',{title:'Głosowanie przerwane',agendaId:first});await act('voteCancel',{id:board.votes.at(-1).id});await act('display',{mode:'break'});
 assert.equal((await call('/api/sessions',{eventId,version:board.version,action:'agendaCurrent',id:first},radny)).status,403);
 assert.equal((await call('/api/records',{record:{id:board.id,kind:'sessionBoard',title:'Nadpisanie',votes:[]}},manager)).status,400);
 assert.equal((await call('/api/records',undefined,radny)).data.records.some(r=>r.kind==='sessionBoard'),false);
 return board;
}
