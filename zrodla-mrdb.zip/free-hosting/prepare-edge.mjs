import {copyFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),target=path.join(root,'supabase/functions/_shared');await mkdir(target,{recursive:true});
for(const [source,name]of [['free-hosting/storage-adapter.mjs','storage-adapter.mjs'],['lib/session-board.mjs','session-board.mjs'],['lib/session-attendance.mjs','session-attendance.mjs'],['lib/mrdb-service.mjs','mrdb-service.mjs'],['lib/committees.mjs','committees.mjs'],['free-hosting/pg-adapter.mjs','pg-adapter.mjs'],['free-hosting/edge-handler.mjs','edge-handler.mjs']])await copyFile(path.join(root,source),path.join(target,name));
console.log('Przygotowano funkcję Supabase.');
