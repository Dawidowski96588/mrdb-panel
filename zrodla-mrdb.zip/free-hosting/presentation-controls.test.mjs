import {test} from 'node:test';
import assert from 'node:assert/strict';
import {presentationCommand,presentationShortcut} from '../app/presentation-controls.mjs';
const board={display:{mode:'resolution',resolutionId:'r',page:0},resolutions:[{id:'r',attachment:{pages:3}}],agenda:[{id:'a'},{id:'b'}],currentAgendaId:'a'};
test('Skróty prezentacji nie przechwytują wpisywania i kombinacji systemowych',()=>{
 assert.equal(presentationShortcut({key:'ArrowRight'}),'next');assert.equal(presentationShortcut({key:' ',shiftKey:true}),'previous');
 for(const key of ['ctrlKey','altKey','metaKey','repeat','isComposing'])assert.equal(presentationShortcut({key:'ArrowRight',[key]:true}),null);
 assert.equal(presentationShortcut({key:'ArrowRight',target:{closest:()=>({})}}),null);
 assert.equal(presentationShortcut({key:' ',target:{closest:s=>s==='button,a,[role="button"]'?{}:null}}),null);
});
test('Strony są ograniczone do dokumentu, a zmiana strony zachowuje powiększenie',()=>{
 assert.equal(presentationCommand(board,'previous'),null);assert.equal(presentationCommand(board,'first'),null);
 assert.equal(presentationCommand(board,'next').data.page,1);assert.equal(presentationCommand(board,'last').data.page,2);
 const last={...board,display:{...board.display,page:2,zoom:1.5,position:'bottom'}};
 assert.equal(presentationCommand(last,'next'),null);assert.equal(presentationCommand(last,'previous').data.zoom,1.5);assert.equal(presentationCommand(last,'previous').data.position,'top');
 assert.equal(presentationCommand(board,'delete'),null);
});
test('Powiększenie i fragmenty mają granice; punkty obrad działają jako slajdy',()=>{
 assert.equal(presentationCommand(board,'zoomOut'),null);assert.equal(presentationCommand(board,'zoomIn').data.zoom,1.5);assert.equal(presentationCommand(board,'fragmentDown'),null);
 const enlarged={...board,display:{...board.display,zoom:2,position:'bottom'}};assert.equal(presentationCommand(enlarged,'zoomIn'),null);assert.equal(presentationCommand(enlarged,'zoomReset').data.zoom,1);assert.equal(presentationCommand(enlarged,'fragmentDown'),null);assert.equal(presentationCommand(enlarged,'fragmentUp').data.position,'threequarter');
 const agenda={...board,display:{mode:'agenda'}};assert.deepEqual(presentationCommand(agenda,'next'),{action:'agendaCurrent',data:{id:'b'}});assert.equal(presentationCommand(agenda,'previous'),null);
});
