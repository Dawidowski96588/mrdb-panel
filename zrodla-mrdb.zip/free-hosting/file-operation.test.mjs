import {test} from 'node:test';
import assert from 'node:assert/strict';
import {abortable,timedOperation} from '../app/file-operation.mjs';

test('Dodawanie pliku można przerwać, nawet gdy odczyt nigdy nie odpowie',async()=>{
 const job=timedOperation(1000,'Limit czasu');
 try{const result=abortable(new Promise(()=>{}),job.signal);job.controller.abort(new Error('Przerwano'));await assert.rejects(result,/Przerwano/);}finally{job.dispose();}
});
test('Zawieszony odczyt kończy się komunikatem limitu czasu',async()=>{
 const job=timedOperation(10,'Odczyt trwa zbyt długo');
 try{await assert.rejects(abortable(new Promise(()=>{}),job.signal),/Odczyt trwa zbyt długo/);}finally{job.dispose();}
});
test('Poprawny wynik i błąd pliku są zachowywane',async()=>{
 const job=timedOperation(1000,'Limit czasu');
 try{assert.equal(await abortable(Promise.resolve(2),job.signal),2);await assert.rejects(abortable(Promise.reject(new Error('Błędny PDF')),job.signal),/Błędny PDF/);}finally{job.dispose();}
});
