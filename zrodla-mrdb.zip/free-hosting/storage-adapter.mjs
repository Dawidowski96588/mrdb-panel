// Reuse the caller's transaction. The Edge pool has one connection: opening a
// second query here while a session save owns that connection would deadlock.
export function createPrivateBucket({DB,baseUrl,headers,fetchImpl=fetch}){
 const metadata=async(key,database=DB)=>{
  const row=await database.prepare('SELECT name,metadata FROM file_metadata WHERE id=?').bind(key).first();
  return row?{customMetadata:{...(row.metadata||{}),name:row.name}}:null;
 };
 return {
  async put(key,data,options){
   const meta=options.customMetadata||{};
   const response=await fetchImpl(`${baseUrl}/storage/v1/object/mrdb-documents/${key}`,{method:'POST',headers:{...headers,'Content-Type':'application/octet-stream'},body:data,signal:AbortSignal.timeout(20000)});
   if(!response.ok)throw Error('Nie udało się zapisać załącznika.');
   await DB.prepare('INSERT INTO file_metadata(id,name,metadata) VALUES(?,?,?::jsonb)').bind(key,meta.name||'dokument',JSON.stringify(meta)).run();
  },
  head:metadata,
  async setMetadata(key,meta,database=DB){await database.prepare('UPDATE file_metadata SET metadata=?::jsonb WHERE id=?').bind(JSON.stringify(meta),key).run();},
  async get(key,database=DB){
   const info=await metadata(key,database);if(!info)return null;
   const response=await fetchImpl(`${baseUrl}/storage/v1/object/authenticated/mrdb-documents/${key}`,{headers,signal:AbortSignal.timeout(20000)});
   if(response.status===404)return null;if(!response.ok)throw Error('Nie udało się odczytać załącznika.');
   return {body:response.body,...info};
  }
 };
}
