// D1-shaped parameterized queries against PostgreSQL; never accepts SQL from the browser.
const tables=['records','history','auth_users','auth_sessions','auth_limits','app_settings','file_metadata'];
export function translate(sql,previousChanges=0){
 let next=sql.replace(/\bchanges\(\)/g,String(Number(previousChanges))).replace(/\browid\b/g,'created_seq');
 const ignore=/^INSERT OR IGNORE /i.test(next);next=next.replace(/^INSERT OR IGNORE /i,'INSERT ');
 if(ignore)next+=' ON CONFLICT DO NOTHING';
 for(const table of tables)next=next.replace(new RegExp('\\b(FROM|JOIN|INTO|UPDATE)\\s+'+table+'\\b','gi'),`$1 mrdb.${table}`);
 // Auth limits uses SQLite's unqualified target columns in an UPSERT.
 next=next.replace(/ELSE count\+1 END/g,'ELSE auth_limits.count+1 END').replace(/WHEN expires</g,'WHEN auth_limits.expires<').replace(/ELSE expires END/g,'ELSE auth_limits.expires END');
 let index=0;next=next.replace(/\?/g,()=>`$${++index}`);return next;
}
export function createDatabase(driver){
 async function execute(client,statement,previous=0){const result=await client.query(translate(statement.sql,previous),statement.args);return {results:result.rows,meta:{changes:Number(result.rowCount||0)}};}
 class Statement{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Statement(this.sql,args.map(v=>v===undefined?null:v));}async first(){return (await execute(driver,this)).results[0]||null;}async all(){return execute(driver,this);}async run(){if(this.sql.includes('WHERE NOT EXISTS(SELECT 1 FROM auth_users)'))return driver.transaction(async client=>{await client.query('SELECT pg_advisory_xact_lock(322,1)',[]);return execute(client,this);});return execute(driver,this);}}
 return {prepare:sql=>new Statement(sql),atomic:fn=>driver.transaction(async client=>{await client.query('LOCK TABLE mrdb.records IN SHARE ROW EXCLUSIVE MODE',[]);const tx={query:(sql,args)=>client.query(sql,args),transaction:callback=>callback(tx)};return fn(createDatabase(tx));}),batch:statements=>driver.transaction(async client=>{let previous=0;const results=[];for(const statement of statements){const r=await execute(client,statement,previous);previous=r.meta.changes;results.push(r);}return results;})};
}
