# Bezpłatna wersja testowa: GitHub Pages + Supabase

Frontend: `https://dawidowski96588.github.io/mrdb-panel/` po włączeniu Pages. API: `https://nhafnglpszaegvsihhtz.supabase.co/functions/v1/mrdb-api`.

Nie jest potrzebna własna domena, własny serwer, konto ChatGPT ani AI. GitHub udostępnia publiczne pliki interfejsu; Supabase uruchamia serwer aplikacji, prywatną bazę PostgreSQL i magazyn plików. Logowanie odbywa się przez własne konta panelu. Nie ma otwartej rejestracji.

## Pierwsze konto

Pierwsze konto przewodniczącego wymaga jednorazowego kodu przekazanego właścicielowi poza repozytorium. W bazie przechowywany jest tylko skrót SHA-256 tego kodu w prywatnej tabeli `mrdb.server_config`. Po utworzeniu pierwszego konta następna konfiguracja jest blokowana. Pozostałe konta dodaje przewodniczący lub koordynator z panelu, a użytkownicy zmieniają hasła tymczasowe przy pierwszym logowaniu.

## Architektura i ochrona danych

- `free-hosting/entry.tsx` ładuje publiczny adres API z `config.json`; nie wymaga klucza administracyjnego w przeglądarce.
- `app/api-client.ts` obsługuje tokeny sesji w pamięci sesji karty. Hasła ani tokeny nie trafiają do adresów dokumentów. Pobieranie załączników wymaga zalogowanej sesji.
- `supabase/functions/mrdb-api/index.ts` działa wyłącznie po stronie serwera, korzysta z domyślnego `SUPABASE_DB_URL` oraz serwerowego klucza Supabase do magazynu plików.
- `lib/mrdb-service.mjs` sprawdza własne konta, scrypt, sesje, role i wersje wpisów.
- `free-hosting/pg-adapter.mjs` wykonuje parametryzowane zapytania i transakcje PostgreSQL; SQL nigdy nie jest przyjmowany od przeglądarki.
- Schemat `mrdb` nie jest udostępniany rolom `anon` ani `authenticated`; wszystkie tabele mają RLS bez publicznych reguł dostępu.
- Bucket `mrdb-documents` jest prywatny. Nie dodawaj publicznych polityk dostępu do dokumentów.
- `verify_jwt=false` dotyczy bramki Supabase, ponieważ API sprawdza własne tokeny panelu. To nie wyłącza logowania ani uprawnień aplikacji.
- CORS dopuszcza tylko adres `https://dawidowski96588.github.io`; można zmienić go przez serwerową zmienną `MRDB_ALLOWED_ORIGINS`. Nie używaj `*`.

## Budowanie i aktualizacja

```sh
npm ci
npm run test:free
npm run build:free
```

Ustaw zmienną środowiskową `MRDB_API_BASE=https://nhafnglpszaegvsihhtz.supabase.co/functions/v1/mrdb-api`, a następnie uruchom:

```sh
node free-hosting/configure-pages.mjs
node free-hosting/package-publish.mjs
```

Katalog `outputs/free-publish` zawiera pliki do umieszczenia w głównym katalogu repozytorium. W GitHub **Settings → Pages** wybierz **Deploy from a branch**, gałąź `main`, katalog `/ (root)`. Zmiana tych plików uruchamia publikację Pages. Jest to aktualizacja gotowego interfejsu; nie resetuje bazy.

Alternatywnie można przechowywać pełne źródła w głównym katalogu repozytorium i używać przygotowanego `.github/workflows/pages.yml`. Wtedy ustaw **Source: GitHub Actions** i dodaj publiczną zmienną repozytorium `MRDB_API_BASE` z powyższym adresem. Nie ustawiaj jednocześnie dwóch metod publikacji.

Zmiana serwera API:

```sh
npm run prepare:edge
supabase functions deploy mrdb-api --project-ref nhafnglpszaegvsihhtz --no-verify-jwt
```

Wgranie funkcji wymaga konta z uprawnieniami projektu. Migracje w `supabase/migrations` stosuj jednokrotnie. Nie nadpisuj istniejących tabel ani migracji. Nowy projekt wymaga osobnego skonfigurowania kodu pierwszego uruchomienia — nie umieszczaj tego kodu w repozytorium.

## Darmowe limity i kopie

Używamy organizacji Supabase `MRDB-App`, plan Free. Nie uruchomiono płatnej subskrypcji. Darmowy plan ma ograniczenia miejsca i transferu; projekt może zostać uśpiony po okresie małej aktywności. Kopie danych trzeba wykonywać samodzielnie. Nie ma gwarancji nieprzerwanej dostępności do zastosowań krytycznych. Szczegóły: [Supabase Free](https://supabase.com/pricing).

## Zastane tabele starszego projektu

W projekcie istnieją także starsze, obecnie puste tabele `public.profiles`, `public.announcements`, `public.events`, `public.support_tickets` i `public.group_messages`, które nie mają włączonego RLS. Nowy panel ich nie używa i nie zapisuje tam danych. Pozostawiono je bez zmian, aby nie naruszyć poprzedniej aplikacji. Przed ich ponownym użyciem właściciel powinien dobrać reguły dostępu. [Wyjaśnienie RLS](https://supabase.com/docs/guides/database/postgres/row-level-security).

## Telefon, instalacja i biblioteka

Interfejs automatycznie reaguje na szerokość ekranu. Do 767 px używa dolnej nawigacji, zwijanych filtrów i domyślnej listy kalendarza. Zmiana rozmiaru okna nie wymaga ponownego logowania.

Pliki PWA w `public-pwa` są kopiowane przez Vite. Publikuj również `manifest.webmanifest`, `sw.js`, `offline.html`, `icon-192.png`, `icon-512.png` i `apple-touch-icon.png`. `configure-pages.mjs` oznacza service worker aktualnym identyfikatorem kompilacji; po nowym wdrożeniu panel proponuje odświeżenie. Chrome udostępnia instalację z menu lub przycisku aplikacji. Safari iPhone/iPad: Udostępnij → Do ekranu głównego. Safari Mac: Plik → Dodaj do Docka (w obsługiwanych wersjach).

Service worker przechowuje tylko publiczny komunikat braku połączenia. Nie zapisuje odpowiedzi API, sesji, dokumentów ani danych rady. Praca z rejestrami wymaga internetu.

Foldery i dokumenty pozostają prywatnymi rekordami w istniejącej bazie; aktualizacja nie wymaga migracji. Prezydium i administratorzy tworzą foldery i podfoldery, zmieniają ich nazwy oraz przypisują i przenoszą dokumenty za pomocą pola Folder. Radni mogą przeglądać bibliotekę i pobierać załączniki. Kolor wydarzenia zapisuje się w rekordzie wydarzenia i historii zmian; stare wydarzenia otrzymują domyślną zieleń.

## Usuwanie i kosz

Przyciski kosza przy dokumentach i folderach są dostępne prezydium, przewodniczącemu i koordynatorowi. Usunięcie jest odwracalne: rekordy otrzymują oznaczenie kosza, załączniki pozostają w prywatnym magazynie. Folder trafia do kosza z aktywnymi dokumentami i podfolderami. Potwierdzenie zawiera aktualne liczby oraz skrót wersji; zmiana zawartości wymaga ponownego potwierdzenia. Przywrócenie odtwarza cały usunięty zestaw. Element usunięty wcześniej osobno wymaga osobnego przywrócenia; najpierw trzeba przywrócić jego folder nadrzędny.

PostgreSQL serializuje zapisy rejestrów i operacje kosza w transakcji z blokadą tabeli records. Serwer SQLite używa transakcji BEGIN IMMEDIATE i kolejki żądań. Radni nie otrzymują zawartości kosza ani dostępu do załącznika, gdy wszystkie jego dokumenty znajdują się w koszu. Operacje są rejestrowane w historii.

## Prowadzenie obecności podczas sesji

W zakładce Obecność wybierz wydarzenie i rozpocznij sprawdzanie. Funkcję prowadzą osoby z prezydium, przewodniczący i koordynator. Przed startem wybiera się osoby z ręcznej listy radnych lub aktywnych kont; lista jest zapisywana jako skład tego wydarzenia. Koordynator nie jest domyślnie zaznaczany jako radny.

Obecność, spóźnienie, nieobecność, usprawiedliwienie, wyjście i powrót tworzą kolejne wpisy z godziną serwera i nazwą prowadzącego. Korekta dopisuje nowy status wraz z obowiązkowym powodem. Zamknięcie listy blokuje zmiany do jej wznowienia z uzasadnieniem. Zapisy mają kontrolę wersji i transakcyjną blokadę, więc równoczesna obsługa nie nadpisuje wpisów.

Panel sesji i sesyjna lista obecności są dostępne wyłącznie dla prezydium, przewodniczącego i koordynatora. Radni oraz przewodniczący komisji nie mają dostępu do tych widoków ani ich API. Szczegóły są wyłączone także z ogólnego API rejestrów. Raport CSV zawiera podsumowanie i szczegółowy przebieg, z godzinami dla Warszawy. Widok odświeża się co 15 sekund i ma przycisk ręcznego odświeżenia. Wcześniejsze proste listy pozostają dostępne w osobnej sekcji. Nowy tryb korzysta z istniejących prywatnych rekordów, bez migracji bazy.

## Panel Sesje i ekran projekcji

Sesje to osobna zakładka z częściami Prowadzenie, Porządek obrad, Uchwały, Głosowania i Obecność. Panel tworzy się dla wybranego wydarzenia z kalendarza. Prezydium, przewodniczący i koordynator układają porządek, wybierają aktualny punkt, wpisują uchwały oraz ręczne wyniki głosowań. Uchwały są kopiowane do biblioteki dokumentów wraz z ostatnim ważnym wynikiem. Po otwarciu głosowania treść uchwały w panelu jest zablokowana; nową wersję dodaje się osobno.

Wybrana przez właściciela zasada wyniku: przyjęto, gdy liczba głosów za jest większa od przeciw; remis oznacza odrzucenie. Jednogłośne przyjęcie lub odrzucenie wymaga co najmniej jednego głosu za/przeciw i zera głosów wstrzymujących. Liczby głosów są całkowite, nieujemne. Rozbieżność z kompletną listą obecności wymaga wyjaśnienia. Korekta opublikowanego wyniku tworzy nowy wpis z powodem i zachowuje zastąpiony wynik. Głosowania można eksportować do CSV.

Przycisk Otwórz ekran na drugi monitor otwiera osobne okno bez panelu zarządzania. W razie blokady okien można użyć widocznego linku Otwórz ekran w osobnej karcie i przenieść kartę do osobnego okna. Oba okna muszą działać w tym samym profilu przeglądarki. Przeciągnij projekcję na projektor/drugi monitor i włącz pełny ekran. Panel prowadzącego trzeba pozostawić otwarty w zakładce Sesje.

Projekcja używa lokalnego BroadcastChannel o losowej nazwie przekazywanej w fragmencie adresu. Nie przekazuje tokenów sesji, danych logowania, operatorów ani prywatnych powodów korekt. Okno jest otwierane z noopener/noreferrer i nie wymaga logowania, nie pobiera danych z API. Odbiera wyłącznie wybrany obraz: powitanie, punkt obrad, tekst uchwały (stronicowany), trwające głosowanie, wynik, przerwę, zakończenie lub czarny ekran. Po utracie połączenia z panelem lub bazą wyświetla komunikat zamiast nieaktualnego wyniku. W przeglądarce prowadzącego działa podgląd projekcji. Prywatne wpisy panelu i obecności są wykluczone z ogólnego API rejestrów; radni nie mają dostępu do panelu Sesje ani sesyjnej listy obecności. Odczyt i zapis przez oba endpointy wymagają rangi Prezydium, Przewodniczący lub Koordynator.


## Dysk Google i pliki uchwał (aktualizacja 11 listopada 2026)

Zakładka Dokumenty otwiera folder MRDB na Dysku Google w nowej karcie. Nie używa klucza Google API ani indeksu konta /u/2 — użytkownik wybiera własne konto Google. Odczyt, edycja, dodawanie i usuwanie plików w Dysku podlegają jego uprawnieniom. Google blokuje osadzanie wskazanego folderu, więc panel udostępnia bezpośredni przycisk. Dotychczasowe rekordy biblioteki pozostają w bazie, ale zastąpiono jej widok. Aktualizacja nie migruje ani nie usuwa wcześniejszych plików.

Sesje → Uchwały → Dodaj uchwałę / Plik i edycja: dodaj PDF, PNG lub JPG do 10 MB, numer, tytuł i punkt obrad. Word / Google Docs należy wcześniej wyeksportować jako PDF. Plik jest przechowywany w prywatnym magazynie aplikacji i nie jest kopiowany automatycznie na Dysk Google. Pliki sesji są dostępne wyłącznie prezydium, przewodniczącemu i koordynatorowi. Serwer sprawdza sygnaturę formatu i odczytuje metadane załącznika z magazynu; nie ufa nazwie ani typowi przesłanym przy zapisie uchwały. Uchwała z otwartym lub opublikowanym głosowaniem jest zablokowana do edycji.

Pokaż uchwałę wyświetla dokument na drugim ekranie. W części Prowadzenie zmieniaj strony PDF-a, powiększenie (cała strona, 150%, 200%) i fragment strony (góra, środek, dół). PDF.js i jego worker są hostowane razem z aplikacją, bez zewnętrznego serwera przetwarzającego dokumenty. Panel pobiera plik z uwierzytelnionego API i przekazuje wyłącznie wybrany dokument przez lokalny BroadcastChannel; projekcja nie otrzymuje tokenu i sama nie wywołuje API. Sekrety pozostają w Supabase, nigdy w plikach GitHub Pages.


### Odporne dodawanie pliku uchwały

Czytnik korzysta z wariantu zgodności PDF.js (legacy) i jawnie uruchomionego Web Workera. Nie przechodzi na przetwarzanie PDF w głównym wątku przeglądarki po awarii workera. Formularz pokazuje etap sprawdzania / wysyłania, pozwala przerwać dodawanie i zachowuje wpisane dane. Cała operacja ma limit 60 sekund; podgląd PDF — 30 sekund. Po anulowaniu lub przekroczeniu czasu żądanie jest przerywane, a proces odczytu kończony. Podgląd ogranicza rozmiar powierzchni renderowania do 8 milionów pikseli. Testy obejmują osobny proces odczytu, nieprawidłowy PDF, limit czasu i przerwanie zawieszonej operacji.


### Zapis uchwały z załącznikiem — poprawka transakcji (12 listopada 2026)

Przed wdrożeniem nowej funkcji zastosuj również migrację `20261112104942_file_metadata_details.sql`. Dodaje prywatną kolumnę JSONB z metadanymi załącznika; zachowuje istniejące nazwy i pliki, bez nowych uprawnień publicznych. Funkcja używa współdzielonego adaptera `storage-adapter.mjs`, przygotowywanego przez `prepare:edge`. Weryfikacja załącznika w zapisie sesji korzysta z połączenia bieżącej transakcji. Otwieranie dodatkowego zapytania przez globalną pulę o rozmiarze 1 blokowałoby zapis. Starsze pliki mają odtwarzane metadane przy zapisie uchwały na podstawie prywatnych bajtów i dotychczasowej liczby stron; nowy upload zachowuje pełne metadane od początku. Test PostgreSQL używa tego samego adaptera i odrzuca zapytania na drugim połączeniu podczas aktywnej transakcji.


### Układ dokumentu i usuwanie uchwał

Ekran uchwały ma informacje po lewej (28%) i dokument po prawej (72%). Domyślne dopasowanie do szerokości pokazuje czytelny fragment PDF-a, a prowadzący wybiera fragment strony (pięć pozycji), powiększenie lub całą stronę. PDF jest renderowany ponownie w większej rozdzielczości; pamięć zależy od widocznego fragmentu, nie wysokości całej strony.

Usuń uchwałę wymaga potwierdzenia i uprawnień prowadzącego. Otwarte głosowanie trzeba wcześniej zakończyć albo anulować. Uchwała znika z aktywnej listy, powiązany dokument trafia do kosza, załącznik i pełny zapis uchwały pozostają prywatne. Wyniki głosowań pozostają zachowane. Ekran wyświetlający usuniętą uchwałę wraca do punktu obrad. Zmiana jest wersjonowana i zapisywana w historii.
