# Bezpłatna wersja testowa: GitHub Pages + Supabase

Frontend: `https://dawidowski96588.github.io/mrdb-panel/` po włączeniu Pages. API: `https://nhafnglpszaegvsihhtz.supabase.co/functions/v1/mrdb-api`.

Nie jest potrzebna własna domena, własny serwer, konto ChatGPT ani AI. GitHub udostępnia publiczne pliki interfejsu; Supabase uruchamia serwer aplikacji, prywatną bazę PostgreSQL i magazyn plików. Logowanie odbywa się przez własne konta panelu. Nie ma otwartej rejestracji.

## Pierwsze konto

Pierwsze konto przewodniczącego wymaga jednorazowego kodu przekazanego właścicielowi poza repozytorium. W bazie przechowywany jest tylko skrót SHA-256 tego kodu w prywatnej tabeli `mrdb.server_config`. Po utworzeniu pierwszego konta następna konfiguracja jest blokowana. Pozostałe konta dodaje przewodniczący lub koordynator z panelu, a użytkownicy zmieniają hasła tymczasowe przy pierwszym logowaniu.

## Architektura i ochrona danych

- `free-hosting/entry.tsx` ładuje publiczny adres API z `config.json`; nie wymaga klucza administracyjnego w przeglądarce.
- `app/api-client.ts` obsługuje tokeny sesji w pamięci sesji karty. Hasła ani tokeny nie trafiają do adresów dokumentów. Pobieranie załączników wymaga zalogowanej sesji.
- `supabase/functions/mrdb-api/index.ts` działa wyłącznie po stronie serwera, korzysta z domyślnego `SUPABASE_DB_URL` oraz serwerowego klucza Supabase do magazynu plików.
- `lib/mrdb-service.mjs` sprawdza własne konta, scrypt, sesje, role i wersje wpisów.
- `free-hosting/pg-adapter.mjs` wykonuje parametryzowane zapytania i transakcje PostgreSQL; SQL nigdy nie jest przyjmowany od przeglądarki.
- Schemat `mrdb` nie jest udostępniany rolom `anon` ani `authenticated`; wszystkie tabele mają RLS bez publicznych reguł dostępu.
- Bucket `mrdb-documents` jest prywatny. Nie dodawaj publicznych polityk dostępu do dokumentów.
- `verify_jwt=false` dotyczy bramki Supabase, ponieważ API sprawdza własne tokeny panelu. To nie wyłącza logowania ani uprawnień aplikacji.
- CORS dopuszcza tylko adres `https://dawidowski96588.github.io`; można zmienić go przez serwerową zmienną `MRDB_ALLOWED_ORIGINS`. Nie używaj `*`.

## Budowanie i aktualizacja

```sh
npm ci
npm run test:free
npm run build:free
```

Ustaw zmienną środowiskową `MRDB_API_BASE=https://nhafnglpszaegvsihhtz.supabase.co/functions/v1/mrdb-api`, a następnie uruchom:

```sh
node free-hosting/configure-pages.mjs
node free-hosting/package-publish.mjs
```

Katalog `outputs/free-publish` zawiera pliki do umieszczenia w głównym katalogu repozytorium. W GitHub **Settings → Pages** wybierz **Deploy from a branch**, gałąź `main`, katalog `/ (root)`. Zmiana tych plików uruchamia publikację Pages. Jest to aktualizacja gotowego interfejsu; nie resetuje bazy.

Alternatywnie można przechowywać pełne źródła w głównym katalogu repozytorium i używać przygotowanego `.github/workflows/pages.yml`. Wtedy ustaw **Source: GitHub Actions** i dodaj publiczną zmienną repozytorium `MRDB_API_BASE` z powyższym adresem. Nie ustawiaj jednocześnie dwóch metod publikacji.

Zmiana serwera API:

```sh
npm run prepare:edge
supabase functions deploy mrdb-api --project-ref nhafnglpszaegvsihhtz --no-verify-jwt
```

Wgranie funkcji wymaga konta z uprawnieniami projektu. Migracje w `supabase/migrations` stosuj jednokrotnie. Nie nadpisuj istniejących tabel ani migracji. Nowy projekt wymaga osobnego skonfigurowania kodu pierwszego uruchomienia — nie umieszczaj tego kodu w repozytorium.

## Darmowe limity i kopie

Używamy organizacji Supabase `MRDB-App`, plan Free. Nie uruchomiono płatnej subskrypcji. Darmowy plan ma ograniczenia miejsca i transferu; projekt może zostać uśpiony po okresie małej aktywności. Kopie danych trzeba wykonywać samodzielnie. Nie ma gwarancji nieprzerwanej dostępności do zastosowań krytycznych. Szczegóły: [Supabase Free](https://supabase.com/pricing).

## Zastane tabele starszego projektu

W projekcie istnieją także starsze, obecnie puste tabele `public.profiles`, `public.announcements`, `public.events`, `public.support_tickets` i `public.group_messages`, które nie mają włączonego RLS. Nowy panel ich nie używa i nie zapisuje tam danych. Pozostawiono je bez zmian, aby nie naruszyć poprzedniej aplikacji. Przed ich ponownym użyciem właściciel powinien dobrać reguły dostępu. [Wyjaśnienie RLS](https://supabase.com/docs/guides/database/postgres/row-level-security).

## Telefon, instalacja i biblioteka

Interfejs automatycznie reaguje na szerokość ekranu. Do 767 px używa dolnej nawigacji, zwijanych filtrów i domyślnej listy kalendarza. Zmiana rozmiaru okna nie wymaga ponownego logowania.

Pliki PWA w `public-pwa` są kopiowane przez Vite. Publikuj również `manifest.webmanifest`, `sw.js`, `offline.html`, `icon-192.png`, `icon-512.png` i `apple-touch-icon.png`. `configure-pages.mjs` oznacza service worker aktualnym identyfikatorem kompilacji; po nowym wdrożeniu panel proponuje odświeżenie. Chrome udostępnia instalację z menu lub przycisku aplikacji. Safari iPhone/iPad: Udostępnij → Do ekranu głównego. Safari Mac: Plik → Dodaj do Docka (w obsługiwanych wersjach).

Service worker przechowuje tylko publiczny komunikat braku połączenia. Nie zapisuje odpowiedzi API, sesji, dokumentów ani danych rady. Praca z rejestrami wymaga internetu.

Foldery i dokumenty pozostają prywatnymi rekordami w istniejącej bazie; aktualizacja nie wymaga migracji. Prezydium i administratorzy tworzą foldery i podfoldery, zmieniają ich nazwy oraz przypisują i przenoszą dokumenty za pomocą pola Folder. Radni mogą przeglądać bibliotekę i pobierać załączniki. Kolor wydarzenia zapisuje się w rekordzie wydarzenia i historii zmian; stare wydarzenia otrzymują domyślną zieleń.
