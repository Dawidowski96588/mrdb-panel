import assert from 'node:assert/strict';
export async function checkSessionAttendance(call,manager,radny){
 const added=await call('/api/records',{record:{kind:'event',title:'Test sesji i obecności',type:'Sesja rady',date:'2026-11-09'}},manager);assert.equal(added.status,200);const event=added.data.record;
 const get=(token=manager)=>call('/api/session-attendance?eventId='+event.id,undefined,token);
 assert.equal((await get()).data.session,null);const candidates=(await get()).data.candidates;const chosen=[candidates.find(c=>c.role==='Prezydium'),candidates.find(c=>c.role==='Radny / radna')];assert.ok(chosen.every(Boolean));
 assert.equal((await get(radny)).status,403);
 const start={action:'start',eventId:event.id,eventVersion:event.version,participants:chosen.map(c=>c.id)};
 assert.equal((await call('/api/session-attendance',{...start,participants:['user:fake']},manager)).status,400);
 assert.equal((await call('/api/session-attendance',start,radny)).status,403);
 let response=await call('/api/session-attendance',start,manager);assert.equal(response.status,200);let session=response.data.session;assert.equal(session.summary.unmarked,2);assert.equal(session.summary.inside,0);
 assert.equal((await call('/api/session-attendance',start,manager)).status,409);
 async function action(action,memberId,extra={},expected=200){const r=await call('/api/session-attendance',{eventId:event.id,version:session.version,action,memberId,...extra},manager);assert.equal(r.status,expected,JSON.stringify(r.data));if(r.status===200)session=r.data.session;return r;}
 const first=chosen[0].id,second=chosen[1].id;
 await action('return',first,{},400);await action('exit',first,{},400);
 await action('present',first,{at:'2000-01-01',actor:'Fałszywy autor',after:{inside:false}});assert.equal(session.summary.inside,1);assert.notEqual(session.entries[0].at,'2000-01-01');assert.notEqual(session.entries[0].actor,'Fałszywy autor');
 await action('present',first,{},400);await action('exit',first);assert.equal(session.summary.inside,0);assert.equal(session.members.find(m=>m.id===first).status,'Poza salą');
 await action('return',first);assert.equal(session.summary.inside,1);
 await action('late',second);assert.equal(session.summary.inside,2);assert.equal(session.members.find(m=>m.id===second).status,'Spóźniony');
 await action('correction',second,{status:'Nieobecny'},400);
 await action('correction',second,{status:'Nieobecny',reason:'Omyłkowe zaznaczenie — korekta'});assert.equal(session.summary.inside,1);assert.equal(session.entries.length,5);
 const denied=await get(radny);assert.equal(denied.status,403);assert.equal(denied.data.session,undefined);
 for(const token of [radny,manager])assert.equal((await call('/api/records',undefined,token)).data.records.some(r=>r.kind==='sessionAttendance'),false);
 assert.equal((await call('/api/session-attendance',{eventId:event.id,action:'close',version:1},manager)).status,409);
 const close={eventId:event.id,version:session.version,action:'close'};
 const concurrent=await Promise.all([call('/api/session-attendance',close,manager),call('/api/session-attendance',close,manager)]);assert.deepEqual(concurrent.map(r=>r.status).sort(),[200,409]);session=concurrent.find(r=>r.status===200).data.session;assert.equal(session.phase,'closed');
 await action('exit',first,{},409);await action('reopen',undefined,{},400);
 await action('reopen',undefined,{reason:'Uzupełnienie listy po przerwie'});assert.equal(session.closedAt,null);
 await action('excused',second);await action('close');assert.equal(session.phase,'closed');assert.equal(session.entries.length,9);
 assert.equal((await call('/api/records',{record:{id:session.id,kind:'sessionAttendance',title:'Nadpisanie',entries:[]}},manager)).status,400);
 assert.equal((await get()).data.session.entries.length,9);
 assert.equal((await call('/api/session-attendance',{eventId:event.id,version:session.version,action:'reopen',reason:'Nieuprawnione'},radny)).status,403);
 return event.id;
}
