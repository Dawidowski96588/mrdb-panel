import assert from 'node:assert/strict';
export async function checkLibraryDeletion(call,manager,radny,fileKey){
 const add=async record=>{const r=await call('/api/records',{record},manager);assert.equal(r.status,200);return r.data.record;};
 const plan=async(id,restore=false)=>{const r=await call('/api/library',{id,action:restore?'previewRestore':'preview'},manager);assert.equal(r.status,200);return r.data;};
 const act=(p,restore=false,token=manager)=>call('/api/library',{id:p.target.id,action:restore?'restore':'trash',revision:p.revision},token);
 const root=await add({kind:'folder',title:'Folder do testu usuwania'}),nested=await add({kind:'folder',title:'Podfolder',parentFolderId:root.id}),doc=await add({kind:'document',title:'Dokument z załącznikiem',parentFolderId:nested.id,fileKey});
 assert.equal((await call('/api/library',undefined,radny)).status,403);
 assert.equal((await call('/api/library',{id:root.id,action:'preview'},radny)).status,403);
 const preview=await plan(root.id);assert.equal(preview.documents,1);assert.equal(preview.folders,2);
 assert.ok((await call('/api/records',undefined,manager)).data.records.some(r=>r.id===doc.id));
 const other=await add({kind:'document',title:'Dodany po potwierdzeniu',parentFolderId:root.id});
 assert.equal((await act(preview)).status,409);
 const ready=await plan(root.id);assert.equal((await act(ready,false,radny)).status,403);assert.equal((await act(ready)).status,200);assert.equal((await act(ready)).status,409);
 assert.equal((await call('/api/records',undefined,radny)).data.records.some(r=>[root.id,nested.id,doc.id,other.id].includes(r.id)),false);
 assert.equal((await call('/api/files?key='+fileKey,undefined,radny)).status,404);
 assert.equal((await call('/api/records',{record:doc},manager)).status,409);
 assert.equal((await call('/api/records',{record:{kind:'document',title:'Pod usuniętym folderem',parentFolderId:nested.id}},manager)).status,400);
 const trash=(await call('/api/library',undefined,manager)).data.trash;assert.ok(trash.some(r=>r.id===root.id&&r.items===4));
 const restore=await plan(root.id,true);assert.equal((await act(restore,true,radny)).status,403);assert.equal((await act(restore,true)).status,200);
 const back=(await call('/api/records',undefined,manager)).data.records;assert.equal(back.find(r=>r.id===doc.id).fileKey,fileKey);assert.equal(back.find(r=>r.id===doc.id).parentFolderId,nested.id);
 assert.equal((await call('/api/records',{record:{...back.find(r=>r.id===doc.id),deletedAt:'',trashBatchId:''}},manager)).status,403);
 // A child trashed separately stays in the trash when its parent is restored.
 assert.equal((await act(await plan(doc.id))).status,200);
 assert.equal((await act(await plan(root.id))).status,200);
 assert.equal((await call('/api/library',{id:doc.id,action:'previewRestore'},manager)).status,409);
 assert.equal((await act(await plan(root.id,true),true)).status,200);
 assert.equal((await call('/api/records',undefined,manager)).data.records.some(r=>r.id===doc.id),false);
 assert.equal((await act(await plan(doc.id,true),true)).status,200);
 // Leave only trashed fixture records so callers' existing active record counts remain stable.
 assert.equal((await act(await plan(root.id))).status,200);
 const history=(await call('/api/records',undefined,manager)).data.history;assert.ok(history.some(h=>h.action==='Przeniesiono do kosza'));assert.ok(history.some(h=>h.action==='Przywrócono z kosza'));
}
