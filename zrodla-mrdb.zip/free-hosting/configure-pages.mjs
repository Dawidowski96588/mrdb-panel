import {mkdir,writeFile,readFile} from 'node:fs/promises';
const apiBase=process.env.MRDB_API_BASE;
if(!apiBase||!/^https:\/\/[a-z0-9]+\.supabase\.co\/functions\/v1\/mrdb-api$/.test(apiBase))throw Error('Ustaw MRDB_API_BASE na adres wdrożonej funkcji Supabase.');
await mkdir('outputs/github-pages',{recursive:true});await writeFile('outputs/github-pages/config.json',JSON.stringify({apiBase}));await writeFile('outputs/github-pages/.nojekyll','');
console.log('Zapisano publiczny adres API. Żadne klucze nie są publikowane.');

const html=await readFile('outputs/github-pages/index.html','utf8');const sw=await readFile('public-pwa/sw.js','utf8');await writeFile('outputs/github-pages/sw.js',sw+'\n// Build: '+(html.match(/index-[^\"]+\.js/)?.[0]||Date.now())+'\n');
