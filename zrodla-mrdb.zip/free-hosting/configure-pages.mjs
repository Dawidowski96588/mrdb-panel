import {mkdir,writeFile} from 'node:fs/promises';
const apiBase=process.env.MRDB_API_BASE;
if(!apiBase||!/^https:\/\/[a-z0-9]+\.supabase\.co\/functions\/v1\/mrdb-api$/.test(apiBase))throw Error('Ustaw MRDB_API_BASE na adres wdrożonej funkcji Supabase.');
await mkdir('outputs/github-pages',{recursive:true});await writeFile('outputs/github-pages/config.json',JSON.stringify({apiBase}));await writeFile('outputs/github-pages/.nojekyll','');
console.log('Zapisano publiczny adres API. Żadne klucze nie są publikowane.');
