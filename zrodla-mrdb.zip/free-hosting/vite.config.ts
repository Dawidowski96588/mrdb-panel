import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {fileURLToPath} from 'node:url';
export default defineConfig({root:fileURLToPath(new URL('.',import.meta.url)),base:'./',publicDir:'../public-pwa',plugins:[react()],build:{rollupOptions:{output:{assetFileNames:asset=>asset.names.some(n=>n.endsWith('.mjs'))?'assets/[name]-[hash].js':'assets/[name]-[hash][extname]'}},outDir:'../outputs/github-pages',emptyOutDir:true,target:'es2022'}});
