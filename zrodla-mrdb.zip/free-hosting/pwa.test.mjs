import {test} from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import vm from 'node:vm';
test('PWA: poprawne ikony, względny zakres i brak prywatnych danych w cache',async()=>{
 const base=new URL('../public-pwa/',import.meta.url),manifest=JSON.parse(await readFile(new URL('manifest.webmanifest',base),'utf8'));
 assert.equal(manifest.scope,'./');assert.equal(manifest.start_url,'./');assert.equal(manifest.display,'standalone');
 for(const icon of manifest.icons){const png=await readFile(new URL(icon.src,base));const size=Number(icon.sizes.split('x')[0]);assert.equal(png.readUInt32BE(16),size);assert.equal(png.readUInt32BE(20),size);}
 const handlers={},added=[],cache={add:async request=>added.push(request.url)},scope='https://example.org/mrdb-panel/';
 const context={URL,Request,Response,Promise,self:{registration:{scope},location:{origin:'https://example.org'},addEventListener:(type,callback)=>handlers[type]=callback,clients:{claim:async()=>{}}},caches:{open:async()=>cache,keys:async()=>[],match:async()=>new Response('offline'),delete:async()=>true},fetch:async()=>{throw Error('offline');}};
 vm.runInNewContext(await readFile(new URL('sw.js',base),'utf8'),context);
 await handlers.install({waitUntil:p=>p});assert.deepEqual(added,[scope+'offline.html']);
 let response;const event=(url,mode='cors')=>({request:{url,method:'GET',mode},respondWith:p=>response=p});
 handlers.fetch(event('https://private.supabase.co/api/records'));assert.equal(response,undefined);
 handlers.fetch(event(scope+'api/files?key=private'));assert.equal(response,undefined);
 handlers.fetch(event(scope,'navigate'));assert.equal(await (await response).text(),'offline');assert.deepEqual(added,[scope+'offline.html']);
});
