import {test} from 'node:test';
import assert from 'node:assert/strict';
import {documentViewport} from '../lib/document-viewport.mjs';
test('PDF wypełnia prawą kolumnę, a fragment jest renderowany w wysokiej rozdzielczości',()=>{
 const params={pageWidth:595,pageHeight:842,width:1200,height:780};
 const top=documentViewport(params),bottom=documentViewport({...params,position:'bottom'});
 assert.equal(top.width,1198);assert.ok(top.height<=780);assert.equal(top.pixelRatio,2);assert.equal(top.offsetY,0);assert.ok(bottom.offsetY>800);assert.equal(top.width,bottom.width);
 const whole=documentViewport({...params,fit:'page'});assert.ok(whole.width<top.width);assert.equal(whole.offsetY,0);
 for(const position of ['top','quarter','middle','threequarter','bottom']){const view=documentViewport({...params,width:2600,height:1600,zoom:2,position});assert.ok(view.width*view.height*view.pixelRatio**2<=8000001);assert.ok(view.offsetY>=0);}
});
