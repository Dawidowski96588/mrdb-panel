import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Worker,MessageChannel} from 'node:worker_threads';
import {getDocument,PDFWorker} from 'pdfjs-dist/legacy/build/pdf.mjs';

function fixture(){
 const stream='BT /F1 18 Tf 30 150 Td (MRDB test) Tj ET';
 const objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 200] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>',`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'];
 let pdf='%PDF-1.4\n';const offsets=[0];for(const [i,obj] of objects.entries()){offsets.push(pdf.length);pdf+=`${i+1} 0 obj\n${obj}\nendobj\n`;}const xref=pdf.length;pdf+='xref\n0 6\n0000000000 65535 f \n';for(const n of offsets.slice(1))pdf+=String(n).padStart(10,'0')+' 00000 n \n';pdf+=`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
 return new TextEncoder().encode(pdf);
}
test('PDF jest odczytywany przez osobny proces roboczy, bez trybu fake worker',async()=>{
 const {port1,port2}=new MessageChannel();
 const source="const {workerData}=require('node:worker_threads');import(workerData.module).then(({WorkerMessageHandler})=>{WorkerMessageHandler.initializeFromPort(workerData.port);workerData.port.start();});";
 const thread=new Worker(source,{eval:true,workerData:{module:new URL('../node_modules/pdfjs-dist/legacy/build/pdf.worker.mjs',import.meta.url).href,port:port2},transferList:[port2]});
 port1.start();const worker=new PDFWorker({port:port1});let task;
 try{task=getDocument({data:fixture(),worker});const doc=await Promise.race([task.promise,new Promise((_,reject)=>{const timer=setTimeout(()=>reject(Error('Worker nie odpowiada')),10000);timer.unref();})]);assert.equal(doc.numPages,1);const page=await doc.getPage(1);assert.equal(page.getViewport({scale:1}).width,300);await task.destroy();task=getDocument({data:new TextEncoder().encode('%PDF broken'),worker});await assert.rejects(task.promise);await task.destroy();}
 finally{worker.destroy();port1.close();await thread.terminate();}
});
