import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readSetupCode,clearSetupCode} from '../app/setup-code.mjs';
test('Kod konfiguracji: nowy link, odświeżenie, zmiana fragmentu i zakończenie',()=>{
 const data=new Map(),storage={setItem:(k,v)=>data.set(k,v),getItem:k=>data.get(k),removeItem:k=>data.delete(k)};
 const location={hash:'#setup=pierwszy-kod',pathname:'/mrdb-panel/',search:''};let address='';
 const history={replaceState:(_a,_b,url)=>{address=url;location.hash='';}};
 assert.equal(readSetupCode(location,storage,history),'pierwszy-kod');assert.equal(address,'/mrdb-panel/');
 assert.equal(readSetupCode(location,storage,history),'pierwszy-kod');
 location.hash='#setup=nowy-kod';assert.equal(readSetupCode(location,storage,history),'nowy-kod');
 clearSetupCode(storage);assert.equal(readSetupCode(location,storage,history),'');
});
