export function createEdgeHandler(handleApi,env){
 const origins=env.ALLOWED_ORIGINS||[];
 return async function handle(request){
  const url=new URL(request.url),origin=request.headers.get('origin');
  const cors={'Vary':'Origin','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'authorization, content-type','Access-Control-Expose-Headers':'Content-Disposition','Access-Control-Max-Age':'600'};
  if(origin&&!origins.includes(origin))return Response.json({error:'Niedozwolone źródło żądania.'},{status:403});
  if(origin)cors['Access-Control-Allow-Origin']=origin;
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
  if(!['GET','POST'].includes(request.method))return new Response(null,{status:405,headers:cors});
  const prefix=['/functions/v1/mrdb-api','/mrdb-api'].find(p=>url.pathname.startsWith(p+'/api/'));
  if(!prefix)return Response.json({error:'Nie znaleziono zasobu.'},{status:404,headers:cors});
  const canonical=new URL(url.pathname.slice(prefix.length)+url.search,url.origin);
  const headers=new Headers(request.headers);headers.delete('cookie');
  headers.set('cf-connecting-ip',request.headers.get('x-forwarded-for')?.split(',')[0].trim()||'unknown');
  if(Number(headers.get('content-length')||0)>11*1024*1024)return Response.json({error:'Za dużo danych.'},{status:413,headers:cors});
  try{
   const body=request.method==='POST'?await request.arrayBuffer():undefined;
   if(body&&body.byteLength>11*1024*1024)return Response.json({error:'Za dużo danych.'},{status:413,headers:cors});
   const response=await handleApi(new Request(canonical,{method:request.method,headers,...(body?{body}:{})}),{...env,SESSION_TRANSPORT:'bearer'});
   const output=new Headers(response.headers);output.delete('set-cookie');for(const [k,v]of Object.entries(cors))output.set(k,v);
   return new Response(response.body,{status:response.status,headers:output});
  }catch{ return Response.json({error:'Nie udało się obsłużyć żądania.'},{status:500,headers:cors});}
 };
}
