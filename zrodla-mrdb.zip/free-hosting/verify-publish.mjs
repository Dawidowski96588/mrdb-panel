import {readFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
// Verify the actual published bytes, including lazy-loaded PDF assets.
const base=process.argv[2]||'https://dawidowski96588.github.io/mrdb-panel/';
const names=['index.html','sw.js','zrodla-mrdb.zip',...await readdir('outputs/github-pages/assets')];
for(const name of names){
 const expected=await readFile('outputs/free-publish/'+name),response=await fetch(new URL(name+'?verify='+Date.now(),base));
 if(!response.ok)throw Error(name+': HTTP '+response.status);
 const actual=Buffer.from(await response.arrayBuffer()),hash=b=>createHash('sha256').update(b).digest('hex');
 if(hash(expected)!==hash(actual))throw Error(name+': opublikowany plik różni się od kompilacji');
 if(name.startsWith('pdf.worker')){
  if(!/javascript/.test(response.headers.get('content-type')||''))throw Error(name+': nieprawidłowy typ MIME');
  const check=spawnSync(process.execPath,['--input-type=module','--check'],{input:actual});
  if(check.status!==0)throw Error(name+': nieprawidłowa składnia JavaScript');
 }
 console.log('OK '+name+' ('+actual.length+' bajtów)');
}
