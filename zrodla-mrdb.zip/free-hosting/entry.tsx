import React from 'react';
import {createRoot} from 'react-dom/client';
import App from '../app/page';
import '../app/globals.css';
const root=createRoot(document.getElementById('root')!);
try{
 const response=await fetch(new URL('./config.json',window.location.href));if(!response.ok)throw Error();const config=await response.json() as {apiBase:string};
 const endpoint=new URL(config.apiBase);if(endpoint.protocol!=='https:'||!endpoint.hostname.endsWith('.supabase.co')||endpoint.pathname!=='/functions/v1/mrdb-api'||endpoint.search||endpoint.hash||endpoint.username||endpoint.password)throw Error();
 window.__MRDB_API_BASE__=endpoint.href.replace(/\/$/,'');root.render(<App/>);
}catch{root.render(<div className="access-loading"><p>Panel oczekuje na skonfigurowanie połączenia z bazą. Skontaktuj się z administratorem.</p></div>);}
