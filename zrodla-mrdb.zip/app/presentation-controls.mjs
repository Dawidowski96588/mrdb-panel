import {resolutionPages} from '../lib/session-board.mjs';
export function presentationShortcut(event){
 if(event.altKey||event.ctrlKey||event.metaKey||event.repeat||event.isComposing)return null;
 const target=event.target;
 if(target?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="slider"]'))return null;
 if(event.key===' '&&target?.closest?.('button,a,[role="button"]'))return null;
 return ({ArrowRight:'next',ArrowLeft:'previous',PageDown:'next',PageUp:'previous',Home:'first',End:'last',ArrowDown:'fragmentDown',ArrowUp:'fragmentUp','+':'zoomIn','=':'zoomIn','-':'zoomOut','0':'zoomReset',' ':event.shiftKey?'previous':'next'})[event.key]||null;
}
export function presentationCommand(board,command){
 if(!board)return null;const display=board.display;
 if(display.mode==='resolution'){
  const resolution=board.resolutions.find(r=>r.id===display.resolutionId);if(!resolution)return null;
  const pages=resolution.attachment?.pages||resolutionPages(resolution.body).length,page=display.page||0;
  const requested=/^page:([1-9]\d{0,2})$/.exec(command);if(requested){const next=Number(requested[1])-1;if(next>=pages||next===page)return null;return {action:'display',data:{...display,page:next,position:'top'}};}
  if(['next','previous','first','last'].includes(command)){
   const next=command==='first'?0:command==='last'?pages-1:page+(command==='next'?1:-1);
   if(next<0||next>=pages||next===page)return null;
   return {action:'display',data:{...display,page:next,position:'top'}};
  }
  if(resolution.attachment&&['zoomIn','zoomOut','zoomReset'].includes(command)){
   const values=[1,1.5,2],index=Math.max(0,values.indexOf(display.zoom||1)),zoom=command==='zoomReset'?1:values[Math.max(0,Math.min(2,index+(command==='zoomIn'?1:-1)))];
   if(zoom===(display.zoom||1))return null;
   return {action:'display',data:{...display,zoom,position:'top'}};
  }
  if(resolution.attachment&&(display.zoom||1)>1&&['fragmentUp','fragmentDown'].includes(command)){
   const positions=['top','quarter','middle','threequarter','bottom'],index=Math.max(0,positions.indexOf(display.position||'top')),next=index+(command==='fragmentDown'?1:-1);
   if(next<0||next>=positions.length)return null;
   return {action:'display',data:{...display,position:positions[next]}};
  }
 }
 if(display.mode==='agenda'&&['next','previous','first','last'].includes(command)){
  const index=board.agenda.findIndex(p=>p.id===board.currentAgendaId),next=command==='first'?0:command==='last'?board.agenda.length-1:index+(command==='next'?1:-1);
  if(next<0||next>=board.agenda.length||next===index)return null;
  return {action:'agendaCurrent',data:{id:board.agenda[next].id}};
 }
 return null;
}
