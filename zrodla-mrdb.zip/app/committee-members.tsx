"use client";
import {useEffect,useState} from 'react';
import {Users,Save} from 'lucide-react';
import {api} from './access';
import {NO_COMMITTEE,COMMITTEE_MEMBER,COMMITTEE_CHAIR} from '../lib/committees.mjs';
type Membership={committee:string;position:string};
type Member={id:string;name:string;role:string;active:boolean;memberships:Membership[]};
export default function CommitteeMembers({onSaved}:{onSaved:()=>void}){
 const [members,Members]=useState<Member[]>([]),[names,Names]=useState<string[]>([]),[selected,Selected]=useState<Member|null>(null),[assignments,Assignments]=useState<Membership[]>([]),[error,ErrorMsg]=useState(''),[message,Message]=useState(''),[busy,Busy]=useState(false),[loading,Loading]=useState(true);
 async function load(){try{const d=await api('/api/committees');Members(d.members);Names(d.committees);}catch(e:any){ErrorMsg(e.message);}finally{Loading(false);}}
 useEffect(()=>{load();},[]);
 return <><div className="accounts-heading"><div><h3>Skład komisji</h3><p>Przypisuj osoby do wielu komisji i wskazuj funkcję w każdej z nich.</p></div><Users size={24}/></div><div className="permissions-note"><p>Prezydium, przewodniczący i koordynator mogą zmieniać przydziały. Funkcja przewodniczącego komisji nie nadaje dostępu do prezydium ani administracji.</p></div>
 {!loading&&!names.length&&<div className="warning">Nie ma jeszcze komisji. Przewodniczący lub koordynator może dodać je w zakładce Funkcje i wygląd.</div>}
 {selected&&<form className="account-form user-edit" onSubmit={async e=>{e.preventDefault();Busy(true);ErrorMsg('');Message('');try{await api('/api/committees',{id:selected.id,memberships:assignments,expectedMemberships:selected.memberships,expectedRole:selected.role});Selected(null);Message('Zapisano komisje i funkcje tej osoby.');await load();onSaved();}catch(e:any){ErrorMsg(e.message);}finally{Busy(false);}}}>
 <h3>{selected.name}</h3><fieldset disabled={busy}><legend>Komisje i funkcje</legend><p>Zaznacz wszystkie komisje, do których należy ta osoba. Przy każdej zaznaczonej komisji wybierz funkcję.</p>
 {[...new Set([...names,...assignments.map(m=>m.committee)])].map(name=>{const assigned=assignments.find(m=>m.committee===name);return <div className="form-grid" key={name}><label className="checkbox-label"><input type="checkbox" checked={!!assigned} onChange={e=>Assignments(prev=>e.target.checked?[...prev,{committee:name,position:COMMITTEE_MEMBER}]:prev.filter(m=>m.committee!==name))}/>{name}</label>{assigned&&<label>Funkcja — {name}<select value={assigned.position} onChange={e=>Assignments(prev=>prev.map(m=>m.committee===name?{...m,position:e.target.value}:m))}><option>{COMMITTEE_MEMBER}</option><option>{COMMITTEE_CHAIR}</option></select></label>}</div>})}
 {!assignments.length&&<p>{NO_COMMITTEE} — nie zaznaczono żadnej komisji.</p>}<button className="secondary" type="button" disabled={!assignments.length} onClick={()=>Assignments([])}>Wyczyść przydziały</button></fieldset>
 <p className="form-description">Można być członkiem kilku komisji i przewodniczyć wybranym komisjom. Rangi przewodniczącego rady, koordynatora i prezydium pozostają zachowane.</p><div className="account-form-footer"><button type="button" className="secondary" disabled={busy} onClick={()=>Selected(null)}>Anuluj</button><button className="primary" disabled={busy}><Save size={15}/>{busy?'Zapisywanie…':'Zapisz przydziały'}</button></div></form>}
 {error&&<div className="error" role="alert">{error}</div>}{message&&<div className="success" role="status">{message}</div>}
 {loading?<p>Wczytywanie składu komisji…</p>:<div className="account-user-list">{members.map(m=><button className="account-user-row" key={m.id} onClick={()=>{Selected(m);Assignments(m.memberships);ErrorMsg('');Message('');}}><span className="avatar">{m.name.split(' ').map(n=>n[0]).slice(0,2).join('')}</span><span><strong>{m.name}</strong><small>{m.memberships.length?m.memberships.map(a=>a.committee+' · '+a.position).join('; '):NO_COMMITTEE}</small></span><span className="role-chip">{m.role}</span>{!m.active&&<small>Zablokowane</small>}</button>)}</div>}</>;
}
