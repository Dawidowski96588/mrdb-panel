"use client";
import {useEffect,useRef,useState} from 'react';
import {abortable,timedOperation} from './file-operation.mjs';
// A locally hosted worker keeps documents inside the two browser windows.
export async function loadPdf(){
 const pdf=await import('pdfjs-dist/legacy/build/pdf.mjs');
 pdf.GlobalWorkerOptions.workerSrc=new URL('../node_modules/pdfjs-dist/legacy/build/pdf.worker.min.mjs',import.meta.url).href;
 return pdf;
}
// Explicit workers prevent PDF.js from falling back to parsing a document on the UI thread.
export async function openPdf(data:Uint8Array,signal:AbortSignal){
 const pdf=await abortable(loadPdf(),signal);if(signal.aborted)throw signal.reason;
 const worker=new Worker(pdf.GlobalWorkerOptions.workerSrc,{type:'module'}),pdfWorker=new pdf.PDFWorker({port:worker});
 let task:any;const failed=new Promise<never>((_,reject)=>{worker.addEventListener('error',()=>reject(Error('Nie udało się uruchomić odczytu PDF. Odśwież panel i spróbuj ponownie.')),{once:true});});
 const destroy=()=>{worker.terminate();pdfWorker.destroy();task?.destroy().catch(()=>{});};
 signal.addEventListener('abort',destroy,{once:true});
 try{task=pdf.getDocument({data,worker:pdfWorker});const doc=await abortable(Promise.race([task.promise,failed]),signal);return {doc,destroy:()=>{signal.removeEventListener('abort',destroy);destroy();}};}catch(e){signal.removeEventListener('abort',destroy);destroy();throw e;}
}
export async function inspectResolutionFile(file:File,signal:AbortSignal){
 if(!file.size)throw Error('Wybrany plik jest pusty.');
 if(file.size>10485760)throw Error('Wybierz plik do 10 MB.');
 if(file.type==='application/pdf'||/\.pdf$/i.test(file.name)){
  const loaded=await openPdf(new Uint8Array(await abortable(file.arrayBuffer(),signal)),signal);
  try{if(loaded.doc.numPages>500)throw Error('Uchwała może mieć maksymalnie 500 stron.');return {mime:'application/pdf',pages:loaded.doc.numPages};}finally{loaded.destroy();}
 }
 if(!['image/png','image/jpeg'].includes(file.type))throw Error('Dodaj PDF, PNG lub JPG. Dokument Word zapisz najpierw jako PDF.');
 const decoding=createImageBitmap(file);decoding.then(bitmap=>{if(signal.aborted)bitmap.close();}).catch(()=>{});
 const bitmap=await abortable(decoding,signal);bitmap.close();return {mime:file.type,pages:1};
}
export default function ResolutionFile({file,page=1,zoom=1,position='top'}:{file:{key:string;blob:Blob;mime:string}|null;page?:number;zoom?:number;position?:string}){
 const host=useRef<HTMLDivElement>(null),canvas=useRef<HTMLCanvasElement>(null),[doc,Doc]=useState<any>(null),[error,ErrorMsg]=useState(''),[url,Url]=useState(''),[size,Size]=useState({width:0,height:0});
 useEffect(()=>{if(!host.current)return;const observer=new ResizeObserver(([entry])=>Size({width:entry.contentRect.width,height:entry.contentRect.height}));observer.observe(host.current);return()=>observer.disconnect();},[]);
 useEffect(()=>{Doc(null);ErrorMsg('');Url('');if(!file)return;let disposed=false,loaded:any;const operation=timedOperation(30000,'Odczyt PDF trwa zbyt długo. Spróbuj ponownie z mniejszym plikiem.'),url=URL.createObjectURL(file.blob);Url(url);if(file.mime==='application/pdf')abortable(file.blob.arrayBuffer(),operation.signal).then(buffer=>openPdf(new Uint8Array(buffer),operation.signal)).then(result=>{loaded=result;operation.dispose();if(disposed)result.destroy();else Doc(result.doc);}).catch(()=>{if(!disposed)ErrorMsg('Nie można odczytać PDF-a. Wróć do panelu prowadzącego i wybierz inny plik.');});return()=>{disposed=true;operation.dispose();operation.controller.abort();loaded?.destroy();URL.revokeObjectURL(url);};},[file?.key,file?.blob]);
 useEffect(()=>{if(!doc||!canvas.current||!size.width||!size.height)return;let cancelled=false,render:any;doc.getPage(page).then((p:any)=>{if(cancelled)return;const v=p.getViewport({scale:1}),scale=Math.min(size.width/v.width,size.height/v.height)*zoom,viewport=p.getViewport({scale}),pixel=Math.min(window.devicePixelRatio||1,2,Math.sqrt(8000000/(viewport.width*viewport.height))),c=canvas.current!;c.width=Math.ceil(viewport.width*pixel);c.height=Math.ceil(viewport.height*pixel);c.style.width=viewport.width+'px';c.style.height=viewport.height+'px';render=p.render({canvas:c,canvasContext:c.getContext('2d'),viewport,transform:[pixel,0,0,pixel,0,0]});return render.promise.then(()=>{const el=host.current;if(el)el.scrollTop=position==='bottom'?el.scrollHeight:position==='middle'?(el.scrollHeight-el.clientHeight)/2:0;});}).catch((e:any)=>{if(!cancelled&&e.name!=='RenderingCancelledException')ErrorMsg('Nie można wyświetlić tej strony dokumentu.');});return()=>{cancelled=true;render?.cancel();};},[doc,page,size,zoom,position]);
 useEffect(()=>{const el=host.current;if(el)el.scrollTop=position==='bottom'?el.scrollHeight:position==='middle'?(el.scrollHeight-el.clientHeight)/2:0;},[position,zoom,page,size,doc]);
 return <div className="resolution-file" ref={host} aria-label={'Dokument uchwały — strona '+page}>{error?<p role="alert">{error}</p>:!file?<p>Wczytywanie dokumentu…</p>:file.mime==='application/pdf'?<canvas ref={canvas}/>:url?<img src={url} alt="Załączony dokument uchwały" style={{maxWidth:zoom===1?'100%':'none',maxHeight:zoom===1?'100%':'none',width:zoom===1?'auto':(zoom*100)+'%'}}/>:null}</div>;
}
