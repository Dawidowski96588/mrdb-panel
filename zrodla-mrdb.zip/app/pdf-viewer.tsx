"use client";
import {useEffect,useRef,useState} from 'react';
// A locally hosted worker keeps documents inside the two browser windows.
export async function loadPdf(){
 const pdf=await import('pdfjs-dist');
 pdf.GlobalWorkerOptions.workerSrc=new URL('../node_modules/pdfjs-dist/build/pdf.worker.min.mjs',import.meta.url).href;
 return pdf;
}
export async function inspectResolutionFile(file:File){
 if(file.size>10485760)throw Error('Wybierz plik do 10 MB.');
 if(file.type==='application/pdf'||/\.pdf$/i.test(file.name)){
  const pdf=await loadPdf(),task=pdf.getDocument({data:new Uint8Array(await file.arrayBuffer())});
  try{const doc=await task.promise;if(doc.numPages>500)throw Error('Uchwała może mieć maksymalnie 500 stron.');return {mime:'application/pdf',pages:doc.numPages};}finally{await task.destroy();}
 }
 if(!['image/png','image/jpeg'].includes(file.type))throw Error('Dodaj PDF, PNG lub JPG. Dokument Word zapisz najpierw jako PDF.');
 const bitmap=await createImageBitmap(file);bitmap.close();return {mime:file.type,pages:1};
}
export default function ResolutionFile({file,page=1,zoom=1,position='top'}:{file:{key:string;blob:Blob;mime:string}|null;page?:number;zoom?:number;position?:string}){
 const host=useRef<HTMLDivElement>(null),canvas=useRef<HTMLCanvasElement>(null),[doc,Doc]=useState<any>(null),[error,ErrorMsg]=useState(''),[url,Url]=useState(''),[size,Size]=useState({width:0,height:0});
 useEffect(()=>{if(!host.current)return;const observer=new ResizeObserver(([entry])=>Size({width:entry.contentRect.width,height:entry.contentRect.height}));observer.observe(host.current);return()=>observer.disconnect();},[]);
 useEffect(()=>{Doc(null);ErrorMsg('');Url('');if(!file)return;let disposed=false,task:any;const url=URL.createObjectURL(file.blob);Url(url);if(file.mime==='application/pdf')loadPdf().then(async pdf=>{if(disposed)return;task=pdf.getDocument({data:new Uint8Array(await file.blob.arrayBuffer())});const doc=await task.promise;if(!disposed)Doc(doc);}).catch(()=>{if(!disposed)ErrorMsg('Nie można odczytać PDF-a. Sprawdź plik w panelu prowadzącego.');});return()=>{disposed=true;task?.destroy();URL.revokeObjectURL(url);};},[file?.key,file?.blob]);
 useEffect(()=>{if(!doc||!canvas.current||!size.width||!size.height)return;let cancelled=false,render:any;doc.getPage(page).then((p:any)=>{if(cancelled)return;const v=p.getViewport({scale:1}),scale=Math.min(size.width/v.width,size.height/v.height)*zoom,viewport=p.getViewport({scale}),pixel=Math.min(window.devicePixelRatio||1,2),c=canvas.current!;c.width=Math.ceil(viewport.width*pixel);c.height=Math.ceil(viewport.height*pixel);c.style.width=viewport.width+'px';c.style.height=viewport.height+'px';render=p.render({canvas:c,canvasContext:c.getContext('2d'),viewport,transform:[pixel,0,0,pixel,0,0]});return render.promise.then(()=>{const el=host.current;if(el)el.scrollTop=position==='bottom'?el.scrollHeight:position==='middle'?(el.scrollHeight-el.clientHeight)/2:0;});}).catch((e:any)=>{if(!cancelled&&e.name!=='RenderingCancelledException')ErrorMsg('Nie można wyświetlić tej strony dokumentu.');});return()=>{cancelled=true;render?.cancel();};},[doc,page,size,zoom,position]);
 useEffect(()=>{const el=host.current;if(el)el.scrollTop=position==='bottom'?el.scrollHeight:position==='middle'?(el.scrollHeight-el.clientHeight)/2:0;},[position,zoom,page,size,doc]);
 return <div className="resolution-file" ref={host} aria-label={'Dokument uchwały — strona '+page}>{error?<p role="alert">{error}</p>:!file?<p>Wczytywanie dokumentu…</p>:file.mime==='application/pdf'?<canvas ref={canvas}/>:url?<img src={url} alt="Załączony dokument uchwały" style={{maxWidth:zoom===1?'100%':'none',maxHeight:zoom===1?'100%':'none',width:zoom===1?'auto':(zoom*100)+'%'}}/>:null}</div>;
}
