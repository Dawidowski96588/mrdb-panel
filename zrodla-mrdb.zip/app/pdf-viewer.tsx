"use client";
import {useEffect,useRef,useState} from 'react';
import {abortable,timedOperation} from './file-operation.mjs';
import {documentViewport} from '../lib/document-viewport.mjs';
// A locally hosted worker keeps documents inside the two browser windows.
export async function loadPdf(){
 const pdf=await import('pdfjs-dist/legacy/build/pdf.mjs');
 pdf.GlobalWorkerOptions.workerSrc=new URL('../node_modules/pdfjs-dist/legacy/build/pdf.worker.min.mjs',import.meta.url).href;
 return pdf;
}
// Explicit workers prevent PDF.js from falling back to parsing a document on the UI thread.
export async function openPdf(data:Uint8Array,signal:AbortSignal){
 const pdf=await abortable(loadPdf(),signal);if(signal.aborted)throw signal.reason;
 const worker=new Worker(pdf.GlobalWorkerOptions.workerSrc,{type:'module'}),pdfWorker=new pdf.PDFWorker({port:worker});
 let task:any;const failed=new Promise<never>((_,reject)=>{worker.addEventListener('error',()=>reject(Error('Nie udało się uruchomić odczytu PDF. Odśwież panel i spróbuj ponownie.')),{once:true});});
 const destroy=()=>{worker.terminate();pdfWorker.destroy();task?.destroy().catch(()=>{});};
 signal.addEventListener('abort',destroy,{once:true});
 try{task=pdf.getDocument({data,worker:pdfWorker});const doc=await abortable(Promise.race([task.promise,failed]),signal);return {doc,destroy:()=>{signal.removeEventListener('abort',destroy);destroy();}};}catch(e){signal.removeEventListener('abort',destroy);destroy();throw e;}
}
export async function inspectResolutionFile(file:File,signal:AbortSignal){
 if(!file.size)throw Error('Wybrany plik jest pusty.');
 if(file.size>10485760)throw Error('Wybierz plik do 10 MB.');
 if(file.type==='application/pdf'||/\.pdf$/i.test(file.name)){
  const loaded=await openPdf(new Uint8Array(await abortable(file.arrayBuffer(),signal)),signal);
  try{if(loaded.doc.numPages>500)throw Error('Uchwała może mieć maksymalnie 500 stron.');return {mime:'application/pdf',pages:loaded.doc.numPages};}finally{loaded.destroy();}
 }
 if(!['image/png','image/jpeg'].includes(file.type))throw Error('Dodaj PDF, PNG lub JPG. Dokument Word zapisz najpierw jako PDF.');
 const decoding=createImageBitmap(file);decoding.then(bitmap=>{if(signal.aborted)bitmap.close();}).catch(()=>{});
 const bitmap=await abortable(decoding,signal);bitmap.close();return {mime:file.type,pages:1};
}
export default function ResolutionFile({file,page=1,zoom=1,position='top',fit='width'}:{file:{key:string;blob:Blob;mime:string}|null;page?:number;zoom?:number;position?:string;fit?:string}){
 const host=useRef<HTMLDivElement>(null),canvas=useRef<HTMLCanvasElement>(null),[doc,Doc]=useState<any>(null),[error,ErrorMsg]=useState(''),[url,Url]=useState(''),[size,Size]=useState({width:0,height:0});
 useEffect(()=>{if(!host.current)return;const observer=new ResizeObserver(([entry])=>Size({width:entry.contentRect.width,height:entry.contentRect.height}));observer.observe(host.current);return()=>observer.disconnect();},[]);
 useEffect(()=>{Doc(null);ErrorMsg('');Url('');if(!file)return;let disposed=false,loaded:any;const operation=timedOperation(30000,'Odczyt PDF trwa zbyt długo. Spróbuj ponownie z mniejszym plikiem.'),url=URL.createObjectURL(file.blob);Url(url);if(file.mime==='application/pdf')abortable(file.blob.arrayBuffer(),operation.signal).then(buffer=>openPdf(new Uint8Array(buffer),operation.signal)).then(result=>{loaded=result;operation.dispose();if(disposed)result.destroy();else Doc(result.doc);}).catch(()=>{if(!disposed)ErrorMsg('Nie można odczytać PDF-a. Wróć do panelu prowadzącego i wybierz inny plik.');});return()=>{disposed=true;operation.dispose();operation.controller.abort();loaded?.destroy();URL.revokeObjectURL(url);};},[file?.key,file?.blob]);
 useEffect(()=>{if(!doc||!canvas.current||!size.width||!size.height)return;let cancelled=false,render:any;ErrorMsg('');doc.getPage(page).then((p:any)=>{if(cancelled)return;const base=p.getViewport({scale:1}),view=documentViewport({pageWidth:base.width,pageHeight:base.height,width:size.width,height:size.height,fit,zoom,position,devicePixelRatio:window.devicePixelRatio||1}),viewport=p.getViewport({scale:view.scale}),pixel=view.pixelRatio,c=canvas.current!;c.width=Math.ceil(view.width*pixel);c.height=Math.ceil(view.height*pixel);c.style.width=view.width+'px';c.style.height=view.height+'px';render=p.render({canvas:c,canvasContext:c.getContext('2d'),viewport,transform:[pixel,0,0,pixel,0,-view.offsetY*pixel]});return render.promise;}).catch((e:any)=>{if(!cancelled&&e.name!=='RenderingCancelledException')ErrorMsg('Nie można wyświetlić tej strony dokumentu.');});return()=>{cancelled=true;render?.cancel();};},[doc,page,size,zoom,position,fit]);
 function positionImage(){const el=host.current;if(el)el.scrollTop=(el.scrollHeight-el.clientHeight)*(({top:0,quarter:.25,middle:.5,threequarter:.75,bottom:1} as any)[position]||0);}
 useEffect(()=>{if(file?.mime!=='application/pdf')positionImage();},[position,zoom,page,size,doc,fit]);
 return <div className="resolution-file" ref={host} aria-label={'Dokument uchwały — strona '+page}>{error?<p role="alert">{error}</p>:!file?<p>Wczytywanie dokumentu…</p>:file.mime==='application/pdf'?<canvas ref={canvas}/>:url?<img src={url} onLoad={positionImage} alt="Załączony dokument uchwały" style={{maxWidth:fit==='page'&&zoom===1?'100%':'none',maxHeight:fit==='page'&&zoom===1?'100%':'none',width:fit==='page'&&zoom===1?'auto':(zoom*100)+'%'}}/>:null}</div>;
}
