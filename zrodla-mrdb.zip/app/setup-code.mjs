const key='mrdb-first-setup-code';
export function readSetupCode(location,storage,history){
 const code=new URLSearchParams(location.hash.slice(1)).get('setup');
 if(code){try{storage.setItem(key,code);}catch{}history.replaceState(null,'',location.pathname+location.search);return code;}
 try{return storage.getItem(key)||'';}catch{return '';}
}
export function clearSetupCode(storage){try{storage.removeItem(key);}catch{}}
