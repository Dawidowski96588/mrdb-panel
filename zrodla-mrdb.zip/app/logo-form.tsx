"use client";
import {useState} from 'react';
import {ImagePlus,Save,RotateCcw} from 'lucide-react';
import {api,type Config} from './access';
export default function LogoForm({config,onSaved}:{config:Config;onSaved:(s:Config)=>void}){
 const [logo,Logo]=useState(config.logoDataUrl||''),[busy,Busy]=useState(false),[error,ErrorMsg]=useState('');
 async function choose(file?:File){ErrorMsg('');if(!file)return;
  if(!['image/png','image/jpeg','image/webp'].includes(file.type)){ErrorMsg('Wybierz obraz PNG, JPG lub WebP.');return;}
  if(file.size>307200){ErrorMsg('Logo może mieć maksymalnie 300 KB.');return;}
  try{const data=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(Error('Nie udało się odczytać pliku.'));reader.readAsDataURL(file);});Logo(data);}catch(e:any){ErrorMsg(e.message);}
 }
 return <form className="account-form" onSubmit={async e=>{e.preventDefault();Busy(true);ErrorMsg('');try{onSaved((await api('/api/branding',{logoDataUrl:logo,version:config.version})).settings);}catch(e:any){ErrorMsg(e.message);}finally{Busy(false);}}}>
  <h3>Logo strony</h3><p className="form-description">Wspólne logo rady jest widoczne na ekranie logowania i w menu panelu. Może je zmieniać prezydium, przewodniczący i koordynator.</p>
  <div className="logo-preview"><span>{logo?<img src={logo} alt="Podgląd wybranego logo"/>:<b>MR</b>}</span><div><strong>{config.shortName}</strong><p>{logo?'Podgląd własnego logo':'Logo domyślne'}</p></div></div>
  <label className="logo-upload"><span><ImagePlus size={20}/>Wybierz plik logo</span><input type="file" accept="image/png,image/jpeg,image/webp" disabled={busy} onChange={e=>choose(e.target.files?.[0])}/><small>PNG, JPG lub WebP · maksymalnie 300 KB. Najlepiej sprawdzi się obraz kwadratowy z przezroczystym tłem.</small></label>
  <button type="button" className="secondary" disabled={busy||!logo} onClick={()=>{Logo('');ErrorMsg('');}}><RotateCcw size={15}/>Przywróć logo domyślne</button>
  {error&&<div className="error" role="alert">{error}</div>}
  <div className="account-form-footer"><span>Zmiana zostanie zapisana w historii.</span><button className="primary" disabled={busy}><Save size={16}/>{busy?'Zapisywanie…':'Zapisz logo'}</button></div>
 </form>;
}
