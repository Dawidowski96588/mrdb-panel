// One transport for the same-origin app and the GitHub Pages test deployment.
declare global {interface Window {__MRDB_API_BASE__?:string}}
const base=()=>typeof window!=='undefined'?(window.__MRDB_API_BASE__||'').replace(/\/$/,''):'';
const tokenKey=()=>`mrdb-session:${base()}`;
export function setSessionToken(token?:string){if(!base())return;if(token)sessionStorage.setItem(tokenKey(),token);else sessionStorage.removeItem(tokenKey());}
export function apiFetch(path:string,init:RequestInit={}){
 if(!path.startsWith('/api/'))throw Error('Nieprawidłowa ścieżka API.');
 const remote=base(),headers=new Headers(init.headers);
 if(remote){const token=sessionStorage.getItem(tokenKey());if(token)headers.set('Authorization','Bearer '+token);}
 const options:RequestInit={...init,headers,credentials:remote?'omit':'same-origin'};
 if(init.signal)return fetch(remote+path,options);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),30000);
 return fetch(remote+path,{...options,signal:controller.signal}).catch(e=>{if(controller.signal.aborted)throw Error('Serwer nie odpowiedział w ciągu 30 sekund. Sprawdź połączenie i spróbuj ponownie.');throw e;}).finally(()=>clearTimeout(timer));
}
export async function downloadFile(key:string){
 const response=await apiFetch('/api/files?key='+encodeURIComponent(key));if(!response.ok){if(response.status===401)window.dispatchEvent(new Event('mrdb-session-expired'));throw Error('Nie udało się pobrać dokumentu.');}
 const blob=await response.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');
 const encoded=response.headers.get('Content-Disposition')?.match(/filename\*=UTF-8''([^;]+)/i)?.[1];a.download=encoded?decodeURIComponent(encoded):'dokument';a.href=url;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
