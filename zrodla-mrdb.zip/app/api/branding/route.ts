import {env} from 'cloudflare:workers';
import {handleApi} from '../../../lib/mrdb-service.mjs';
export const dynamic='force-dynamic';
export const GET=(req:Request)=>handleApi(req,env);
export const POST=(req:Request)=>handleApi(req,env);
