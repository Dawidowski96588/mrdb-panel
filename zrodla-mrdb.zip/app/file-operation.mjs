export function abortError(signal){return signal.reason instanceof Error?signal.reason:new Error('Przerwano dodawanie pliku.');}
export function abortable(promise,signal){
 if(signal.aborted)return Promise.reject(abortError(signal));
 return new Promise((resolve,reject)=>{
  const stop=()=>reject(abortError(signal));signal.addEventListener('abort',stop,{once:true});
  Promise.resolve(promise).then(resolve,reject).finally(()=>signal.removeEventListener('abort',stop));
 });
}
export function timedOperation(milliseconds,message){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(new Error(message)),milliseconds);
 return {controller,signal:controller.signal,dispose:()=>clearTimeout(timer)};
}
