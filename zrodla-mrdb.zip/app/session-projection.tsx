"use client";
import {useEffect,useState} from 'react';
import {Maximize} from 'lucide-react';
export function ProjectionScreen({data}:{data:any}){
 if(!data)return <div className="projection-screen"><h1>Sesja MRDB</h1><p>Oczekiwanie na panel prowadzącego…</p></div>;
 const {mode,vote,resolution,currentPoint}=data;
 if(mode==='blank')return <div className="projection-screen blank"/>;
 return <div className={'projection-screen mode-'+mode}><header>{data.logoDataUrl&&<img src={data.logoDataUrl} alt="Logo rady"/>}<span>{data.councilName||'Młodzieżowa Rada Dzielnicy Białołęka'}</span><strong>{data.shortName||'MRDB'}</strong></header><main>
 {mode==='welcome'&&<><div className="projection-kicker">SESJA RADY</div><h1>{data.title}</h1><p>{data.date}</p></>}
 {mode==='agenda'&&<><div className="projection-kicker">{currentPoint?'TERAZ OMAWIAMY · PUNKT '+currentPoint.number:'PORZĄDEK OBRAD'}</div><h1>{currentPoint?.title||data.title}</h1>{currentPoint?.description&&<p className="projection-description">{currentPoint.description}</p>}<div className="projection-agenda">{data.agenda?.map((p:any)=><div key={p.number} className={p.current?'current':p.done?'done':''}><b>{p.number}.</b><span>{p.title}</span>{p.done&&<small>✓</small>}</div>)}</div></>}
 {mode==='resolution'&&resolution&&<><div className="projection-kicker">UCHWAŁA · {resolution.number}</div><h1>{resolution.title}</h1><div className="projection-resolution">{resolution.text}</div><div className="projection-page">Strona {resolution.page} z {resolution.pages}</div></>}
 {mode==='vote'&&vote&&<><div className="projection-kicker">GŁOSOWANIE</div><h1>{vote.title}</h1><div className="projection-voting">Trwa głosowanie</div><p>Wynik pojawi się po wprowadzeniu go przez prowadzącego.</p></>}
 {mode==='result'&&vote&&<><div className="projection-kicker">WYNIK GŁOSOWANIA {vote.resolutionNumber?'· UCHWAŁA '+vote.resolutionNumber:''}</div><h1>{vote.title}</h1><div className={'projection-outcome '+(vote.outcome==='Przyjęto'?'accepted':'rejected')}>{vote.outcome==='Przyjęto'?'PRZYJĘTO':'ODRZUCONO'}</div>{vote.unanimous&&<div className="projection-unanimous">JEDNOGŁOŚNIE</div>}<div className="projection-vote-counts"><div className="yes"><b>{vote.yes}</b><span>ZA</span></div><div className="no"><b>{vote.no}</b><span>PRZECIW</span></div><div className="abstain"><b>{vote.abstain}</b><span>WSTRZYMAŁO SIĘ</span></div></div><p>Oddano głosów: {vote.total}</p></>}
 {mode==='break'&&<><div className="projection-kicker">{data.title}</div><h1>Przerwa w obradach</h1><p>Prosimy o oczekiwanie na wznowienie sesji.</p></>}
 {mode==='ended'&&<><div className="projection-kicker">{data.title}</div><h1>Zakończenie obrad</h1><p>Dziękujemy za udział w sesji.</p></>}
 </main><footer><span>{data.title}</span>{data.attendance&&<span>Na sali: <b>{data.attendance.inside}</b> / {data.attendance.total}</span>}</footer></div>;
}
export default function ProjectionWindow(){
 const [data,Data]=useState<any>(null),[last,Last]=useState(0),[connected,Connected]=useState(false),[now,Now]=useState(Date.now()),[error,ErrorMsg]=useState('');
 useEffect(()=>{document.title='MRDB · Ekran sesji';const channel=new URLSearchParams(window.location.hash.slice(1)).get('kanal');if(!channel||!/^[-a-f0-9]{36}$/.test(channel)){ErrorMsg('Otwórz ten ekran przyciskiem w panelu Sesje.');return;}if(!('BroadcastChannel' in window)){ErrorMsg('Ta przeglądarka nie obsługuje połączenia okien. Otwórz panel i ekran w aktualnym Chrome lub Safari.');return;}const bus=new BroadcastChannel('mrdb-projector-'+channel);bus.onmessage=e=>{const p=e.data;if(p?.type==='screen'&&p.snapshot?.schema===1){Data(p.snapshot);Last(Date.now());Connected(p.connected===true);}};bus.postMessage({type:'ready'});const timer=setInterval(()=>Now(Date.now()),1000);return()=>{clearInterval(timer);bus.close();};},[]);
 const stale=last>0&&(now-last>35000||!connected);
 return <div className="projection-window"><ProjectionScreen data={data}/>{(error||stale)&&<div className="projection-warning" role="alert">{error||'Brak aktualnego połączenia z panelem prowadzącego. Oczekiwanie na wznowienie.'}</div>}<button className="projection-fullscreen" onClick={()=>{if(document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().catch(()=>ErrorMsg('Włącz pełny ekran z menu przeglądarki.'));else ErrorMsg('Włącz pełny ekran z menu przeglądarki.');}}><Maximize size={18}/>Pełny ekran</button></div>;
}
