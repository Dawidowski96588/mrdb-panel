-- Private file metadata stays behind the existing RLS and schema restrictions.
ALTER TABLE mrdb.file_metadata ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}'::jsonb;
