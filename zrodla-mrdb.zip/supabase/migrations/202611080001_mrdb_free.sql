-- New private schema: existing projects and public tables remain untouched.
CREATE SCHEMA IF NOT EXISTS mrdb;
REVOKE ALL ON SCHEMA mrdb FROM PUBLIC, anon, authenticated;
CREATE TABLE mrdb.records (id text PRIMARY KEY, data text NOT NULL, version integer NOT NULL DEFAULT 1);
CREATE TABLE mrdb.history (id text PRIMARY KEY, data text NOT NULL, created_seq bigint GENERATED ALWAYS AS IDENTITY);
CREATE TABLE mrdb.auth_users (id text PRIMARY KEY,email text NOT NULL UNIQUE,name text NOT NULL,password text NOT NULL,role text NOT NULL,active integer NOT NULL DEFAULT 1,profile text NOT NULL DEFAULT '{}',must_change integer NOT NULL DEFAULT 0);
CREATE TABLE mrdb.auth_sessions (token text PRIMARY KEY,user_id text NOT NULL REFERENCES mrdb.auth_users(id),expires bigint NOT NULL);
CREATE INDEX auth_sessions_expiry ON mrdb.auth_sessions(expires);
CREATE TABLE mrdb.auth_limits (key text PRIMARY KEY,count integer NOT NULL,expires bigint NOT NULL);
CREATE TABLE mrdb.app_settings (id text PRIMARY KEY,data text NOT NULL,version integer NOT NULL DEFAULT 1);
CREATE TABLE mrdb.file_metadata (id text PRIMARY KEY,name text NOT NULL);
CREATE TABLE mrdb.server_config (key text PRIMARY KEY,value text NOT NULL);
ALTER TABLE mrdb.records ENABLE ROW LEVEL SECURITY;
ALTER TABLE mrdb.history ENABLE ROW LEVEL SECURITY;
ALTER TABLE mrdb.auth_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE mrdb.auth_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE mrdb.auth_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE mrdb.app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE mrdb.file_metadata ENABLE ROW LEVEL SECURITY;
ALTER TABLE mrdb.server_config ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON ALL TABLES IN SCHEMA mrdb FROM PUBLIC, anon, authenticated;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA mrdb FROM PUBLIC, anon, authenticated;
-- No public upload or download policies. Only the authenticated application server accesses files.
INSERT INTO storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
VALUES ('mrdb-documents','mrdb-documents',false,10485760,NULL)
ON CONFLICT (id) DO NOTHING;
