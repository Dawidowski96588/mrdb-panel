// This entire module runs server-side. No database or service key is sent to GitHub Pages.
import postgres from 'npm:postgres@3.4.7';
import {handleApi} from '../_shared/mrdb-service.mjs';
import {createDatabase} from '../_shared/pg-adapter.mjs';
import {createEdgeHandler} from '../_shared/edge-handler.mjs';
import {createPrivateBucket} from '../_shared/storage-adapter.mjs';
const sql=postgres(Deno.env.get('SUPABASE_DB_URL')!,{max:1,prepare:false,ssl:'require',idle_timeout:20,connect_timeout:15});
const wrap=(client:any):any=>({query:async(text:string,args:any[])=>{const r=await client.unsafe(text,args);return {rows:[...r],rowCount:r.count};},transaction:(fn:any)=>client.begin((tx:any)=>fn(wrap(tx)))});
const DB=createDatabase(wrap(sql));
const supabaseUrl=Deno.env.get('SUPABASE_URL')!;
const serviceKey=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')||Object.values(JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS')||'{}'))[0] as string;
const storageHeaders={apikey:serviceKey,Authorization:'Bearer '+serviceKey};
const BUCKET=createPrivateBucket({DB,baseUrl:supabaseUrl,headers:storageHeaders});
// Set after creating the Pages repository. No wildcard CORS origins.
const origins=(Deno.env.get('MRDB_ALLOWED_ORIGINS')||'https://dawidowski96588.github.io').split(',').map(v=>v.trim()).filter(Boolean);
Deno.serve(async request=>{
 const config=await sql.unsafe("SELECT value FROM mrdb.server_config WHERE key='setup_token_sha256'");
 return createEdgeHandler(handleApi,{DB,BUCKET,MRDB_SETUP_TOKEN:Deno.env.get('MRDB_SETUP_TOKEN'),MRDB_SETUP_HASH:config[0]?.value,ALLOWED_ORIGINS:origins})(request);
});
