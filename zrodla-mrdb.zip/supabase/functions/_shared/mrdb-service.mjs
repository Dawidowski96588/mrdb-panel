import {boardView,updateBoard} from './session-board.mjs';
import {sessionMembers,nextAttendance,ATTENDANCE_ACTIONS} from './session-attendance.mjs';
import {scrypt,randomBytes,timingSafeEqual,createHash} from 'node:crypto';
import {Buffer} from 'node:buffer';
import {NO_COMMITTEE,WHOLE_COUNCIL,COMMITTEE_CHAIR,COMMITTEE_MEMBER,memberships,committeeNames,actionCommittees} from './committees.mjs';
export const ROLES=['Przewodniczący','Koordynator','Prezydium',COMMITTEE_CHAIR,'Radny / radna'];
export const MODULES={event:'Kalendarz',task:'Zadania',project:'Projekty i akcje',document:'Dokumenty',attendance:'Obecność'};
export const DEFAULT_SETTINGS={title:'Młodzieżowa Rada Dzielnicy Białołęka',shortName:'MRDB',theme:'forest',committees:['Prezydium','Komisja ds. edukacji','Komisja ds. kultury','Komisja ds. spraw społecznych','Komisja ds. sportu'],statuses:['Planowane','W toku','Do akceptacji','Zakończone','Wstrzymane'],eventTypes:['Sesja rady','Posiedzenie komisji','Warsztaty','Prezentacja w szkole','Akcja społeczna','Wolontariat','Spotkanie'],modules:Object.fromEntries(Object.keys(MODULES).map(k=>[k,true]))};
const digest=v=>createHash('sha256').update(v).digest('hex');
const admin=u=>['Przewodniczący','Koordynator'].includes(u.role);
const canSeeHistory=u=>admin(u)||u.role==='Prezydium';
const publicUser=u=>({id:u.id,email:u.email,name:u.name,role:u.role,active:!!u.active,mustChange:!!u.must_change,profile:JSON.parse(u.profile||'{}')});
const fail=(message,status=400)=>{throw Object.assign(new Error(message),{status});};
const json=(data,status=200,headers={})=>Response.json(data,{status,headers:{'Cache-Control':'no-store',...headers}});
const text=(v,max=300)=>typeof v==='string'?v.trim().slice(0,max):'';
const validEmail=v=>typeof v==='string'&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)&&v.length<=254;
export async function hashPassword(password){if(typeof password!=='string'||password.length<12||password.length>128)fail('Hasło musi mieć od 12 do 128 znaków.');const salt=randomBytes(16).toString('hex');const hash=await new Promise((resolve,reject)=>scrypt(password,salt,64,{N:32768,r:8,p:3,maxmem:64*1024*1024},(e,v)=>e?reject(e):resolve(v)));return `scrypt$${salt}$${hash.toString('hex')}`;}
async function verify(password,stored){if(typeof password!=='string'||password.length>128)return false;const [algo,salt,hash]=stored.split('$');if(algo!=='scrypt')return false;const result=await new Promise((resolve,reject)=>scrypt(password,salt,64,{N:32768,r:8,p:3,maxmem:64*1024*1024},(e,v)=>e?reject(e):resolve(v)));return timingSafeEqual(result,Buffer.from(hash,'hex'));}
const cookie=(token,secure,expire=false)=>`mrdb_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${expire?0:43200}${secure?'; Secure':''}`;
function sessionToken(req,env){return env.SESSION_TRANSPORT==='bearer'?req.headers.get('authorization')?.match(/^Bearer ([a-f0-9]{64})$/)?.[1]:req.headers.get('cookie')?.split(';').map(s=>s.trim()).find(s=>s.startsWith('mrdb_session='))?.slice(13);}
export async function getUser(req,env){const token=sessionToken(req,env);if(!token||!/^[a-f0-9]{64}$/.test(token))return null;return env.DB.prepare('SELECT u.* FROM auth_users u JOIN auth_sessions s ON s.user_id=u.id WHERE s.token=? AND s.expires>? AND u.active=1').bind(digest(token),Date.now()).first();}
async function audit(env,u,action,title,before=null,after=null,conditional=false){const log={id:crypto.randomUUID(),date:new Date().toISOString(),actor:u?.email||'Pierwsze uruchomienie',action,title,before,after};return env.DB.prepare(conditional?'INSERT INTO history(id,data) SELECT ?,? WHERE changes()>0':'INSERT INTO history(id,data) VALUES(?,?)').bind(log.id,JSON.stringify(log));}
async function settings(env){const r=await env.DB.prepare("SELECT data,version FROM app_settings WHERE id='main'").first();return r?{...DEFAULT_SETTINGS,...JSON.parse(r.data),version:r.version}:{...DEFAULT_SETTINGS,version:0};}
async function limited(env,key,max=8){const k=digest(key),now=Date.now();const r=await env.DB.prepare('INSERT INTO auth_limits(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN expires<? THEN 1 ELSE count+1 END,expires=CASE WHEN expires<? THEN excluded.expires ELSE expires END RETURNING count').bind(k,now+15*60*1000,now,now).first();if(r.count>max)fail('Zbyt wiele prób. Spróbuj ponownie za 15 minut.',429);}
async function body(req,max=110000){try{const b=await req.json();if(JSON.stringify(b).length>max)fail('Za dużo danych.',413);return b;}catch(e){if(e.status)throw e;fail('Nieprawidłowe dane.');}}
export async function handleApi(req,env){try{return await dispatch(req,env);}catch(e){if(!e.status)console.error('MRDB API:',e.message);return json({error:e.status?e.message:'Nie udało się wykonać operacji. Spróbuj ponownie.'},e.status||500);}}
async function dispatch(req,env){
 const url=new URL(req.url),path=url.pathname,write=!['GET','HEAD'].includes(req.method),secure=url.protocol==='https:';
 if(write){const origin=req.headers.get('origin');const allowed=env.SESSION_TRANSPORT==='bearer'&&env.ALLOWED_ORIGINS?.includes(origin);if(origin&&origin!==url.origin&&!allowed)fail('Niedozwolone źródło żądania.',403);if(req.headers.get('sec-fetch-site')==='cross-site'&&!allowed)fail('Niedozwolone źródło żądania.',403);}
 if(path==='/api/auth/session'&&req.method==='GET'){const u=await getUser(req,env),exists=await env.DB.prepare('SELECT id FROM auth_users LIMIT 1').first();return json({user:u?publicUser(u):null,setupNeeded:!exists,setupEnabled:!!(env.MRDB_SETUP_TOKEN||env.MRDB_SETUP_HASH)});}
 if(path==='/api/auth/setup'&&req.method==='POST'){
  await limited(env,'setup:'+ (req.headers.get('cf-connecting-ip')||'local'),10);const b=await body(req);
  if(!(env.MRDB_SETUP_TOKEN||env.MRDB_SETUP_HASH)||!timingSafeEqual(Buffer.from(digest(String(b.token||''))),Buffer.from(env.MRDB_SETUP_HASH||digest(env.MRDB_SETUP_TOKEN))))fail('Nieprawidłowy kod pierwszego uruchomienia.',403);
  if(!validEmail(b.email)||!text(b.name))fail('Podaj imię, nazwisko i poprawny e-mail.');
  const id=crypto.randomUUID(),hash=await hashPassword(b.password);
  const r=await env.DB.prepare('INSERT INTO auth_users(id,email,name,password,role,active,profile,must_change) SELECT ?,?,?,?,?,1,?,0 WHERE NOT EXISTS(SELECT 1 FROM auth_users)').bind(id,b.email.toLowerCase().trim(),text(b.name),hash,ROLES[0],'{}').run();
  if(!r.meta.changes)fail('Panel został już skonfigurowany.',409);await (await audit(env,null,'Utworzono konto przewodniczącego',b.email)).run();return json({ok:true});
 }
 if(path==='/api/auth/login'&&req.method==='POST'){
  const b=await body(req),email=text(b.email,254).toLowerCase(),ip=req.headers.get('cf-connecting-ip')||'local';await limited(env,'login-ip:'+ip,40);await limited(env,'login-email:'+email,8);
  const u=await env.DB.prepare('SELECT * FROM auth_users WHERE email=?').bind(email).first();
  const stored=u?.password||'scrypt$00000000000000000000000000000000$'+'00'.repeat(64);
  if(!await verify(b.password,stored)||!u?.active)fail('Nieprawidłowy e-mail lub hasło.',401);
  const token=randomBytes(32).toString('hex');await env.DB.batch([env.DB.prepare('DELETE FROM auth_sessions WHERE expires<?').bind(Date.now()),env.DB.prepare('INSERT INTO auth_sessions(token,user_id,expires) VALUES(?,?,?)').bind(digest(token),u.id,Date.now()+43200000)]);
  return json({user:publicUser(u),...(env.SESSION_TRANSPORT==='bearer'?{sessionToken:token}:{})},200,env.SESSION_TRANSPORT==='bearer'?{}:{'Set-Cookie':cookie(token,secure)});
 }
 if(path==='/api/branding'&&req.method==='GET'){const s=await settings(env);return json({branding:{title:s.title,shortName:s.shortName,logoDataUrl:s.logoDataUrl||''}});}
 const u=await getUser(req,env);if(!u)fail('Zaloguj się, aby korzystać z panelu.',401);
 if(path==='/api/auth/logout'&&req.method==='POST'){const token=sessionToken(req,env);if(token)await env.DB.prepare('DELETE FROM auth_sessions WHERE token=?').bind(digest(token)).run();return json({ok:true},200,{'Set-Cookie':cookie('',secure,true)});}
 if(path==='/api/profile'&&req.method==='POST'){
  const b=await body(req);if(!text(b.name)||!validEmail(b.email))fail('Podaj imię, nazwisko i poprawny e-mail.');const email=b.email.trim().toLowerCase();
  const assigned=JSON.parse(u.profile||'{}');
  if((b.memberships!==undefined&&JSON.stringify(b.memberships)!==JSON.stringify(memberships(assigned)))||(b.committees!==undefined)||(b.profile!==undefined)||(b.role!==undefined&&b.role!==u.role)||(b.committee!==undefined&&text(b.committee)!==(assigned.committee||''))||(b.committeeRole!==undefined&&b.committeeRole!==(assigned.committeeRole||'')))fail('Przydział do komisji i funkcję zmienia prezydium lub administrator w zakładce Skład komisji.',403);
  if((b.password||email!==u.email)&&!await verify(b.currentPassword,u.password))fail('Podaj poprawne obecne hasło.',403);
  if(u.must_change&&!b.password)fail('Ustaw nowe własne hasło.');
  if(await env.DB.prepare('SELECT id FROM auth_users WHERE email=? AND id<>?').bind(email,u.id).first())fail('Ten e-mail jest już używany.');
  const profile={...assigned,bio:text(b.bio,1000),color:['green','blue','violet','orange'].includes(b.color)?b.color:'green'};
  const hash=b.password?await hashPassword(b.password):u.password;
  const result=await env.DB.batch([env.DB.prepare('UPDATE auth_users SET name=?,email=?,profile=?,password=?,must_change=0 WHERE id=? AND profile=? AND role=? AND password=?').bind(text(b.name),email,JSON.stringify(profile),hash,u.id,u.profile,u.role,u.password),await audit(env,u,'Zmieniono profil',text(b.name),{name:u.name,email:u.email},{name:text(b.name),email},true),...(b.password?[env.DB.prepare('DELETE FROM auth_sessions WHERE user_id=? AND changes()>0').bind(u.id)]:[])]);
  if(!result[0].meta.changes)fail('Profil lub przydział zmienił się w innym oknie. Odśwież profil.',409);
  return json({ok:true,relogin:!!b.password,user:publicUser({...u,name:text(b.name),email,profile:JSON.stringify(profile),must_change:0})},200,b.password?{'Set-Cookie':cookie('',secure,true)}:{});
 }
 if(u.must_change)fail('Najpierw zmień hasło tymczasowe w swoim profilu.',403);
 if(path==='/api/committees'){
  if(!admin(u)&&u.role!=='Prezydium')fail('Składem komisji zarządza prezydium, przewodniczący lub koordynator.',403);
  const config=await settings(env),names=committeeNames(config.committees);
  if(req.method==='GET'){const users=await env.DB.prepare('SELECT id,name,role,active,profile FROM auth_users ORDER BY name').all();return json({committees:names,members:users.results.map(v=>{const p=JSON.parse(v.profile||'{}');return {id:v.id,name:v.name,role:v.role,active:!!v.active,committee:p.committee||'',position:p.committeeRole||'',memberships:memberships(p)};})});}
  const b=await body(req),target=await env.DB.prepare('SELECT * FROM auth_users WHERE id=?').bind(b.id||'').first();if(!target)fail('Nie znaleziono osoby.',404);
  const old=JSON.parse(target.profile||'{}');
  if(b.role!==undefined)fail('Ta zakładka nie nadaje dostępu do prezydium ani administracji.',403);
  const current=memberships(old);
  if(b.memberships===undefined&&current.length>1)fail("Odśwież panel, aby edytować wiele komisji.",409);
  if((b.memberships!==undefined?JSON.stringify(b.expectedMemberships)!==JSON.stringify(current):b.expectedCommittee!==(old.committee||'')||b.expectedPosition!==(old.committeeRole||''))||b.expectedRole!==target.role)fail('Przydział tej osoby został już zmieniony. Odśwież listę.',409);
  const proposed=b.memberships!==undefined?b.memberships:(b.committee&&b.committee!==NO_COMMITTEE?[{committee:b.committee,position:b.position}]:[]);
  if(!Array.isArray(proposed)||proposed.length>40)fail('Wybierz komisje z listy.');
  const next=proposed.map(m=>{if(!m||typeof m!=='object'||!names.includes(m.committee)||![COMMITTEE_MEMBER,COMMITTEE_CHAIR].includes(m.position))fail('Wybierz istniejącą komisję i funkcję.');return {committee:m.committee,position:m.position};});
  if(new Set(next.map(m=>m.committee)).size!==next.length)fail('Każdą komisję wybierz tylko raz.');
  const profile={...old,memberships:next,committee:next[0]?.committee||'',committeeRole:next[0]?.position||''};
  const role=['Radny / radna',COMMITTEE_CHAIR].includes(target.role)?next.some(m=>m.position===COMMITTEE_CHAIR)?COMMITTEE_CHAIR:'Radny / radna':target.role;
  const before={memberships:current,role:target.role},after={memberships:next,role};
  const result=await env.DB.batch([env.DB.prepare('UPDATE auth_users SET profile=?,role=? WHERE id=? AND profile=? AND role=?').bind(JSON.stringify(profile),role,target.id,target.profile,target.role),await audit(env,u,'Zmieniono skład komisji',target.name,before,after,true)]);
  if(!result[0].meta.changes)fail('Przydział został zmieniony. Odśwież listę.',409);return json({ok:true});
 }
 if(path==='/api/branding'&&req.method==='POST'){
  if(!admin(u)&&u.role!=='Prezydium')fail('Logo może zmieniać prezydium, przewodniczący i koordynator.',403);
  const b=await body(req,420000),old=await settings(env);if(b.version!==old.version)fail('Ustawienia zmieniły się. Odśwież panel przed zmianą logo.',409);
  let logo=b.logoDataUrl;if(typeof logo!=='string')fail('Wybierz plik logo.');
  if(logo){const match=/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(logo);if(!match)fail('Logo musi być obrazem PNG, JPG lub WebP.');const bytes=Buffer.from(match[2],'base64');if(bytes.length>307200)fail('Logo może mieć maksymalnie 300 KB.');
   const ok=match[1]==='png'?bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):match[1]==='jpeg'?bytes[0]===255&&bytes[1]===216&&bytes[2]===255:bytes.subarray(0,4).toString()==='RIFF'&&bytes.subarray(8,12).toString()==='WEBP';if(!ok)fail('Plik nie jest poprawnym obrazem wybranego typu.');}
  const next={...old,logoDataUrl:logo};delete next.version;const id=crypto.randomUUID(),log={id,date:new Date().toISOString(),actor:u.email,action:'Zmieniono logo',title:old.shortName,before:{logo:old.logoDataUrl?'Własne logo':'Logo domyślne'},after:{logo:logo?'Własne logo':'Logo domyślne'}};
  const result=await env.DB.batch([old.version?env.DB.prepare("UPDATE app_settings SET data=?,version=version+1 WHERE id='main' AND version=?").bind(JSON.stringify(next),old.version):env.DB.prepare("INSERT OR IGNORE INTO app_settings(id,data,version) VALUES('main',?,1)").bind(JSON.stringify(next)),env.DB.prepare('INSERT INTO history(id,data) SELECT ?,? WHERE changes()>0').bind(id,JSON.stringify(log))]);if(!result[0].meta.changes)fail('Ustawienia zmieniły się. Odśwież panel.',409);return json({settings:{...next,version:old.version+1}});
 }
 if(path==='/api/settings'){
  if(req.method==='GET')return json({settings:await settings(env)});
  if(!admin(u))fail('Ustawienia są dostępne dla przewodniczącego i koordynatora.',403);
  const b=await body(req,420000),s=b.settings,old=await settings(env);if(!s||s.version!==old.version)fail('Ustawienia zmieniły się. Odśwież panel.',409);
  const lists=['committees','statuses','eventTypes'];for(const key of lists)if(!Array.isArray(s[key])||!s[key].length||s[key].length>40||s[key].some(v=>typeof v!=='string'||!v.trim()||v.length>100))fail('Listy muszą zawierać od 1 do 40 niepustych pozycji.');
  if(!s.statuses.includes('Zakończone')||!s.statuses.includes('W toku'))fail('Zachowaj statusy „Zakończone” i „W toku” używane przez rejestr wykonania.');
  const next={logoDataUrl:old.logoDataUrl||'',title:text(s.title,150),shortName:text(s.shortName,20),theme:['forest','ocean','violet'].includes(s.theme)?s.theme:'forest',modules:Object.fromEntries(Object.keys(MODULES).map(k=>[k,s.modules?.[k]!==false])),...Object.fromEntries(lists.map(k=>[k,[...new Set(s[k].map(v=>v.trim()))]]))};
  if(!next.title||!next.shortName)fail('Podaj nazwę rady i skrót.');
  const settingsLogId=crypto.randomUUID();const results=await env.DB.batch([old.version?env.DB.prepare("UPDATE app_settings SET data=?,version=version+1 WHERE id='main' AND version=?").bind(JSON.stringify(next),old.version):env.DB.prepare("INSERT OR IGNORE INTO app_settings(id,data,version) VALUES('main',?,1)").bind(JSON.stringify(next)),env.DB.prepare('INSERT INTO history(id,data) SELECT ?,? WHERE changes()>0').bind(settingsLogId,JSON.stringify({id:settingsLogId,date:new Date().toISOString(),actor:u.email,action:'Zmieniono ustawienia',title:next.title,before:{...old,logoDataUrl:old.logoDataUrl?'Własne logo':''},after:{...next,logoDataUrl:next.logoDataUrl?'Własne logo':''}}))]);
  if(!results[0].meta.changes)fail('Ustawienia zmieniły się. Odśwież panel.',409);return json({settings:{...next,version:old.version+1}});
 }
 if(path==='/api/users'){
  if(!admin(u))fail('Brak uprawnień do zarządzania kontami.',403);
  if(req.method==='GET'){const all=await env.DB.prepare('SELECT * FROM auth_users ORDER BY name').all();return json({users:all.results.map(publicUser)});}
  const b=await body(req);if(!validEmail(b.email)||!text(b.name)||!ROLES.includes(b.role))fail('Sprawdź dane konta i rolę.');
  const old=b.id?await env.DB.prepare('SELECT * FROM auth_users WHERE id=?').bind(b.id).first():null;
  if(b.id&&!old)fail('Nie znaleziono konta.',404);if(old?.id===u.id&&(b.role!==u.role||b.active===false))fail('Nie możesz odebrać sobie własnych uprawnień.');
  const email=b.email.trim().toLowerCase(),id=old?.id||crypto.randomUUID();if(await env.DB.prepare('SELECT id FROM auth_users WHERE email=? AND id<>?').bind(email,id).first())fail('E-mail jest już używany.');
  const password=b.password?await hashPassword(b.password):old?.password;if(!password)fail('Podaj tymczasowe hasło nowego konta.');
  const active=b.active!==false?1:0,mustChange=!old||b.password?1:old.must_change;
  const command=old?env.DB.prepare("UPDATE auth_users SET email=?,name=?,role=?,active=?,password=?,must_change=? WHERE id=? AND (?=1 OR EXISTS(SELECT 1 FROM auth_users WHERE id<>? AND active=1 AND role IN ('Przewodniczący','Koordynator')))").bind(email,text(b.name),b.role,active,password,mustChange,id,active&&['Przewodniczący','Koordynator'].includes(b.role)?1:0,id):env.DB.prepare('INSERT INTO auth_users(id,email,name,password,role,active,profile,must_change) VALUES(?,?,?,?,?,?,?,?)').bind(id,email,text(b.name),password,b.role,active,'{}',mustChange);
  const log={id:crypto.randomUUID(),date:new Date().toISOString(),actor:u.email,action:old?'Zmieniono konto':'Dodano konto',title:email,before:old?publicUser(old):null,after:{name:text(b.name),email,role:b.role,active:!!active,hasloZresetowane:!!b.password}};
  const results=await env.DB.batch([command,env.DB.prepare('DELETE FROM auth_sessions WHERE user_id=? AND changes()>0').bind(id),env.DB.prepare('INSERT INTO history(id,data) VALUES(?,?)').bind(log.id,JSON.stringify(log))]);if(!results[0].meta.changes)fail('Musi pozostać co najmniej jedno aktywne konto administratora.',409);return json({ok:true});
 }
 const config=await settings(env);
 if(write&&(path==='/api/records'||path==='/api/library'||path==='/api/session-attendance'||path==='/api/sessions')&&env.DB.atomic&&!env.RECORDS_TX)return env.DB.atomic(DB=>dispatch(req,{...env,DB,RECORDS_TX:true}));
 if(path==='/api/sessions'){
  if(!canSeeHistory(u))fail('Panel Sesje jest dostępny wyłącznie dla prezydium, przewodniczącego i koordynatora.',403);
  if(config.modules.attendance===false)fail('Moduł sesji i obecności jest wyłączony.',403);
  const manage=canSeeHistory(u),b=req.method==='GET'?{}:await body(req),eventId=req.method==='GET'?url.searchParams.get('eventId'):b.eventId;
  const all=(await env.DB.prepare('SELECT data,version FROM records').all()).results.map(r=>({...JSON.parse(r.data),version:r.version}));
  const event=all.find(r=>r.id===eventId&&r.kind==='event'&&!r.deletedAt);if(!event)fail('Wybierz wydarzenie z kalendarza.',404);
  const existing=all.find(r=>r.kind==='sessionBoard'&&r.eventId===eventId),att=all.find(r=>r.kind==='sessionAttendance'&&r.eventId===eventId);
  const attendance=att?{inside:sessionMembers(att).filter(m=>m.inside).length,total:att.roster.length,unmarked:sessionMembers(att).filter(m=>m.status==='Nie sprawdzono').length,phase:att.phase}:null;
  if(req.method==='GET')return json({board:boardView(existing,manage),attendance});
  if(!manage)fail('Sesję prowadzi prezydium, przewodniczący lub koordynator.',403);
  if(b.action==='init'){
   if(existing)fail('Panel sesji już istnieje. Odśwież widok.',409);const now=new Date().toISOString(),board={id:crypto.randomUUID(),kind:'sessionBoard',eventId,title:event.title,eventDate:event.date||'',version:1,agenda:[],resolutions:[],votes:[],currentAgendaId:'',display:{mode:'welcome'},createdAt:now,updatedAt:now};
   await env.DB.batch([env.DB.prepare('INSERT INTO records(id,data,version) VALUES(?,?,?)').bind(board.id,JSON.stringify(board),1),await audit(env,u,'Utworzono panel sesji',event.title)]);return json({board,attendance});
  }
  if(!existing)fail('Najpierw utwórz panel sesji.',409);if(b.version!==existing.version)fail('Sesja zmieniła się w innym oknie. Odśwież i ponów czynność.',409);
  if(b.action==='resolutionSave'&&b.attachment){if(!/^[a-f0-9-]{36}$/.test(b.attachment.key||''))fail('Nieprawidłowy plik uchwały.');const obj=await env.BUCKET.get(b.attachment.key);if(!obj||obj.customMetadata?.resolution!=='1')fail('Wgraj plik uchwały ponownie.');b.attachment={key:b.attachment.key,name:obj.customMetadata.name,mime:obj.customMetadata.mime,pages:Number(obj.customMetadata.pages)};}
  const next=updateBoard(existing,b,{id:()=>crypto.randomUUID(),now:new Date().toISOString(),actor:u.name,attendance}),statements=[];
  for(const r of next.resolutions){const before=existing.resolutions.find(x=>x.id===r.id),oldDoc=all.find(x=>x.id===r.documentId),vote=[...next.votes].reverse().find(v=>v.resolutionId===r.id&&v.state==='published');const oldVote=[...existing.votes].reverse().find(v=>v.resolutionId===r.id&&v.state==='published');if(JSON.stringify(before)===JSON.stringify(r)&&oldVote?.id===vote?.id)continue;if(oldDoc?.deletedAt)fail('Powiązana uchwała jest w koszu. Przywróć ją przed zmianą.');
   const doc={...(oldDoc||{}),id:r.documentId,kind:'document',title:r.number+' · '+r.title,type:'Uchwała',description:r.body,date:event.date||'',committee:WHOLE_COUNCIL,parentFolderId:oldDoc?.parentFolderId||'',status:vote?'Zakończone':'W toku',resolutionNumber:r.number,resolutionOutcome:vote?.outcome||'Projekt',sessionEventId:eventId,...(vote?{voteResults:{yes:vote.yes,no:vote.no,abstain:vote.abstain,outcome:vote.outcome,unanimous:vote.unanimous}}:{}),version:(oldDoc?.version||0)+1};
   statements.push(oldDoc?env.DB.prepare('UPDATE records SET data=?,version=? WHERE id=? AND version=?').bind(JSON.stringify(doc),doc.version,doc.id,oldDoc.version):env.DB.prepare('INSERT INTO records(id,data,version) VALUES(?,?,?)').bind(doc.id,JSON.stringify(doc),doc.version));
  }
  const result=await env.DB.batch([env.DB.prepare('UPDATE records SET data=?,version=? WHERE id=? AND version=?').bind(JSON.stringify(next),next.version,next.id,existing.version),...statements,await audit(env,u,'Sesja: '+b.action,existing.title,{wersja:existing.version},{wersja:next.version,ekran:next.display.mode},true)]);if(!result[0].meta.changes)fail('Sesja została zmieniona. Odśwież panel.',409);return json({board:next,attendance});
 }
 if(path==='/api/session-attendance'){
  if(!canSeeHistory(u))fail('Obecność podczas sesji jest dostępna wyłącznie dla prezydium, przewodniczącego i koordynatora.',403);
  if(config.modules.attendance===false)fail('Ewidencja obecności jest wyłączona.',403);
  const manage=canSeeHistory(u),b=req.method==='GET'?{}:await body(req),eventId=req.method==='GET'?url.searchParams.get('eventId'):b.eventId;
  if(!eventId||typeof eventId!=='string')fail('Wybierz wydarzenie.');
  const all=(await env.DB.prepare('SELECT data,version FROM records').all()).results.map(r=>({...JSON.parse(r.data),version:r.version}));
  const event=all.find(r=>r.id===eventId&&r.kind==='event'&&!r.deletedAt);if(!event)fail('Nie znaleziono wydarzenia.',404);
  const existing=all.find(r=>r.kind==='sessionAttendance'&&r.eventId===eventId);
  const view=s=>{if(!s)return null;const members=sessionMembers(s),inside=members.filter(m=>m.inside).length;return {id:s.id,eventId:s.eventId,title:s.title,eventDate:s.eventDate,version:s.version,phase:s.phase,startedAt:s.startedAt,closedAt:s.closedAt||null,members,summary:{inside,total:members.length,unmarked:members.filter(m=>m.status==='Nie sprawdzono').length,everPresent:members.filter(m=>m.everPresent).length},...(manage?{entries:s.entries}:{})};};
  if(req.method==='GET'){
   let candidates=[];if(manage){const users=(await env.DB.prepare('SELECT id,name,role FROM auth_users WHERE active=1 ORDER BY name').all()).results;candidates=[...all.filter(r=>r.kind==='member'&&!r.deletedAt).map(r=>({id:'member:'+r.id,name:r.title,source:'Lista radnych'})),...users.map(r=>({id:'user:'+r.id,name:r.name,source:'Konto panelu',role:r.role}))];}
   return json({session:view(existing),candidates});
  }
  if(!manage)fail('Obecność podczas sesji prowadzi prezydium, przewodniczący lub koordynator.',403);
  if(b.action==='start'){
   if(existing)fail('Lista obecności dla tego wydarzenia już istnieje. Odśwież widok.',409);
   if(b.eventVersion!==event.version)fail('Wydarzenie zostało zmienione. Odśwież kalendarz.',409);
   if(!Array.isArray(b.participants)||!b.participants.length||b.participants.length>150||new Set(b.participants).size!==b.participants.length)fail('Wybierz od 1 do 150 różnych osób.');
   const users=(await env.DB.prepare('SELECT id,name FROM auth_users WHERE active=1').all()).results;
   const candidates=new Map([...all.filter(r=>r.kind==='member'&&!r.deletedAt).map(r=>['member:'+r.id,r.title]),...users.map(r=>['user:'+r.id,r.name])]);
   const roster=b.participants.map(id=>{const name=candidates.get(id);if(!name)fail('Wybrana osoba nie jest już dostępna. Odśwież listę.');return {id,name};});
   const session={id:crypto.randomUUID(),kind:'sessionAttendance',eventId,title:event.title,eventDate:event.date||'',phase:'open',startedAt:new Date().toISOString(),roster,entries:[],version:1};
   await env.DB.batch([env.DB.prepare('INSERT INTO records(id,data,version) VALUES(?,?,?)').bind(session.id,JSON.stringify(session),1),await audit(env,u,'Rozpoczęto sprawdzanie obecności',event.title,null,{osoby:roster.length})]);return json({session:view(session)});
  }
  if(!existing)fail('Najpierw rozpocznij sprawdzanie obecności.',409);
  if(b.version!==existing.version)fail('Obecność została zmieniona w innym oknie. Odśwież listę i ponów czynność.',409);
  if(existing.entries.length>=5000)fail('Osiągnięto limit wpisów dla tej sesji.');
  if(!Object.hasOwn(ATTENDANCE_ACTIONS,b.action))fail('Nieprawidłowa czynność obecności.');
  const reason=text(b.reason,500),entry={id:crypto.randomUUID(),action:b.action,at:new Date().toISOString(),actor:u.name,...(reason?{reason}:{})};
  const session={...existing,entries:[...existing.entries],version:existing.version+1};
  if(b.action==='reopen'){
   if(existing.phase!=='closed')fail('Lista jest już otwarta.');if(!reason)fail('Podaj powód wznowienia listy.');session.phase='open';session.closedAt=null;
  }else{
   if(existing.phase!=='open')fail('Lista jest zamknięta. Najpierw ją wznów.',409);
   if(b.action==='close'){session.phase='closed';session.closedAt=entry.at;}
   else{const member=sessionMembers(existing).find(m=>m.id===b.memberId);if(!member)fail('Osoby nie ma na tej liście.');if(b.action==='correction'&&!reason)fail('Podaj powód korekty.');entry.memberId=member.id;entry.memberName=member.name;entry.before={status:member.status,inside:member.inside,everPresent:member.everPresent};entry.after=nextAttendance(member,b.action,b.status);}
  }
  session.entries.push(entry);
  const results=await env.DB.batch([env.DB.prepare('UPDATE records SET data=?,version=? WHERE id=? AND version=?').bind(JSON.stringify(session),session.version,session.id,existing.version),await audit(env,u,'Obecność: '+ATTENDANCE_ACTIONS[b.action],existing.title,{osoba:entry.memberName||'',status:entry.before?.status||'',faza:existing.phase},{osoba:entry.memberName||'',status:entry.after?.status||'',faza:session.phase,powód:reason},true)]);
  if(!results[0].meta.changes)fail('Obecność zmieniła się. Odśwież listę.',409);return json({session:view(session)});
 }
 if(path==='/api/library'){
  if(!canSeeHistory(u))fail('Biblioteką zarządza prezydium, przewodniczący i koordynator.',403);
  if(config.modules.document===false)fail('Biblioteka dokumentów jest wyłączona.',403);
  const all=(await env.DB.prepare('SELECT data,version FROM records').all()).results.map(r=>({...JSON.parse(r.data),version:r.version}));
  const library=all.filter(r=>['document','folder'].includes(r.kind));
  if(req.method==='GET')return json({trash:library.filter(r=>r.deletedAt&&r.trashRootId===r.id).map(r=>({...r,items:library.filter(x=>x.trashBatchId===r.trashBatchId).length}))});
  const b=await body(req),target=library.find(r=>r.id===b.id);if(!target)fail('Nie znaleziono dokumentu lub folderu.',404);
  if(!['preview','previewRestore','trash','restore'].includes(b.action))fail('Nieprawidłowa operacja.');
  let items;
  if(['restore','previewRestore'].includes(b.action)){
   if(!target.deletedAt||target.trashRootId!==target.id)fail('Wybierz pozycję z kosza.',409);
   items=library.filter(r=>r.trashBatchId===target.trashBatchId);
   if(target.parentFolderId&&!library.some(r=>r.id===target.parentFolderId&&!r.deletedAt))fail('Najpierw przywróć folder nadrzędny.',409);
  }else{
   if(target.deletedAt)fail('Ta pozycja jest już w koszu.',409);
   const ids=new Set([target.id]);let changed=true;while(changed){changed=false;for(const r of library)if(!r.deletedAt&&r.parentFolderId&&ids.has(r.parentFolderId)&&!ids.has(r.id)){ids.add(r.id);changed=true;}}
   items=library.filter(r=>!r.deletedAt&&ids.has(r.id));
  }
  const revision=digest(JSON.stringify(items.map(r=>[r.id,r.version]).sort((a,b)=>a[0].localeCompare(b[0]))));
  const counts={documents:items.filter(r=>r.kind==='document').length,folders:items.filter(r=>r.kind==='folder').length};
  if(['preview','previewRestore'].includes(b.action))return json({target:{id:target.id,title:target.title,kind:target.kind},...counts,revision});
  if(b.revision!==revision)fail('Zawartość zmieniła się. Odśwież listę i potwierdź operację ponownie.',409);
  const batch=crypto.randomUUID(),date=new Date().toISOString(),restoring=b.action==='restore';
  const next=items.map(r=>{const after={...r,version:r.version+1};if(restoring){delete after.deletedAt;delete after.trashBatchId;delete after.trashRootId;}else{after.deletedAt=date;after.trashBatchId=batch;after.trashRootId=target.id;}return after;});
  const log={id:crypto.randomUUID(),date,actor:u.email,action:restoring?'Przywrócono z kosza':'Przeniesiono do kosza',title:target.title,before:{dokumenty:counts.documents,foldery:counts.folders},after:{stan:restoring?'W bibliotece':'W koszu',dokumenty:counts.documents,foldery:counts.folders}};
  const result=await env.DB.batch([...next.map((r,i)=>env.DB.prepare('UPDATE records SET data=?,version=? WHERE id=? AND version=?').bind(JSON.stringify(r),r.version,r.id,items[i].version)),env.DB.prepare('INSERT INTO history(id,data) VALUES(?,?)').bind(log.id,JSON.stringify(log))]);
  if(result.slice(0,next.length).some(r=>!r.meta.changes))fail('Zawartość została zmieniona. Odśwież bibliotekę.',409);
  return json({ok:true,...counts});
 }
 if(path==='/api/records'){
  if(req.method==='GET'){const [r,h]=await Promise.all([env.DB.prepare('SELECT data,version FROM records').all(),canSeeHistory(u)?env.DB.prepare('SELECT data FROM history ORDER BY rowid DESC LIMIT 250').all():Promise.resolve({results:[]})]);return json({records:r.results.map(v=>({...JSON.parse(v.data),version:v.version})).filter(v=>!v.deletedAt&&!['sessionAttendance','sessionBoard'].includes(v.kind)),history:h.results.map(v=>JSON.parse(v.data)),people:(await env.DB.prepare('SELECT id,name,role FROM auth_users WHERE active=1 ORDER BY name').all()).results});}
  const {record}=await body(req);if(!record||!['event','task','project','document','folder','member','attendance'].includes(record.kind)||!text(record.title)||record.title.length>300)fail('Sprawdź dane wpisu.');
  if(['deletedAt','trashBatchId','trashRootId'].some(k=>record[k]!==undefined))fail('Do usuwania i przywracania użyj biblioteki dokumentów.',403);
  if(config.modules[record.kind]===false)fail('Ten moduł został wyłączony w ustawieniach.',403);
  const old=await env.DB.prepare('SELECT data,version FROM records WHERE id=?').bind(record.id||'').first();
  if(old&&old.version!==record.version)fail('Wpis został zmieniony w innym oknie. Odśwież panel.',409);const previous=old?JSON.parse(old.data):null;
  if(previous?.deletedAt)fail('Ta pozycja jest w koszu. Najpierw ją przywróć.',409);
  if(previous&&previous.kind!==record.kind)fail('Nie można zmienić rodzaju wpisu.');
  if(!admin(u)&&u.role!=='Prezydium'){
   if(!['event','project','task'].includes(record.kind))fail('Ta operacja wymaga uprawnień prezydium.',403);
   if(previous&&(previous.ownerId?previous.ownerId!==u.id:previous.owner!==u.name))fail('Możesz edytować tylko własne wpisy i przypisane zadania.',403);
   if(record.owner&&record.owner!==u.name)fail('Nie możesz przypisywać zadań innym osobom.',403);record.owner=u.name;record.ownerId=u.id;
   const assignment=JSON.parse(u.profile||'{}'),organizer=record.committee||NO_COMMITTEE;
   if(previous&&organizer!==(previous.committee||NO_COMMITTEE))fail('Organizatora istniejącego wpisu zmienia prezydium.',403);
   if(!previous&&!actionCommittees(config.committees,{role:u.role,profile:assignment}).includes(organizer))fail('Wybierz własną komisję, Całą MRDB albo Brak komisji.',403);
  }
  if(record.kind==='event'&&record.color!==undefined&&(typeof record.color!=='string'||!/^#[0-9a-fA-F]{6}$/.test(record.color)))fail('Wybierz poprawny kolor wydarzenia.');
  if(['document','folder'].includes(record.kind)){
   if(config.modules.document===false)fail('Biblioteka dokumentów jest wyłączona.',403);
   if(record.parentFolderId!==undefined&&typeof record.parentFolderId!=='string')fail('Wybierz poprawny folder.');
   const parent=record.parentFolderId||'';
   if(record.kind==='folder'&&previous&&parent!==(previous.parentFolderId||''))fail('Przy zmianie nazwy folderu zachowaj jego położenie.');
   if(parent){const folder=await env.DB.prepare('SELECT data FROM records WHERE id=?').bind(parent).first();if(!folder||JSON.parse(folder.data).kind!=='folder'||JSON.parse(folder.data).deletedAt||parent===record.id)fail('Wybrany folder nie istnieje.');}
   record.parentFolderId=parent;
  }
  if(record.kind==='attendance'){
   const member=await env.DB.prepare('SELECT data FROM records WHERE id=?').bind(record.memberId||'').first(),event=await env.DB.prepare('SELECT data FROM records WHERE id=?').bind(record.eventId||'').first();
   if(!member||JSON.parse(member.data).kind!=='member'||!event||JSON.parse(event.data).kind!=='event')fail('Wybierz istniejące wydarzenie i radnego.');
   if(!['Obecny','Nieobecny','Usprawiedliwiony','Spóźniony'].includes(record.status))fail('Nieprawidłowy status obecności.');
  }
  if(record.ownerId){const assigned=await env.DB.prepare('SELECT id,name FROM auth_users WHERE id=? AND active=1').bind(record.ownerId).first();if(!assigned)fail('Wybrane konto jest nieaktywne lub nie istnieje.');record.owner=assigned.name;}
  const id=old?record.id:crypto.randomUUID(),version=old?old.version+1:1,data={...record,id,version};
  const log={id:crypto.randomUUID(),date:new Date().toISOString(),title:record.title,actor:u.email,action:old?'Zaktualizowano':'Dodano',before:previous,after:data};
  const results=await env.DB.batch([old?env.DB.prepare('UPDATE records SET data=?,version=? WHERE id=? AND version=?').bind(JSON.stringify(data),version,id,old.version):env.DB.prepare('INSERT INTO records(id,data,version) VALUES(?,?,?)').bind(id,JSON.stringify(data),version),env.DB.prepare('INSERT INTO history(id,data) SELECT ?,? WHERE changes()>0').bind(log.id,JSON.stringify(log))]);if(!results[0].meta.changes)fail('Wpis został zmieniony. Odśwież panel.',409);return json({record:data,...(canSeeHistory(u)?{log}:{})});
 }
 if(path==='/api/files'){
  if(req.method==='GET'){const key=url.searchParams.get('key');if(!key||!/^[a-f0-9-]{36}$/.test(key))fail('Brak pliku.',404);if(!canSeeHistory(u)){const linked=(await env.DB.prepare('SELECT data FROM records').all()).results.map(r=>JSON.parse(r.data)).filter(r=>r.fileKey===key);if(linked.length&&linked.every(r=>r.deletedAt))fail('Dokument jest w koszu.',404);}const obj=await env.BUCKET.get(key);if(!obj)fail('Brak pliku.',404);if(obj.customMetadata?.resolution==='1'&&!canSeeHistory(u))fail('Pliki panelu sesji są dostępne wyłącznie dla prowadzących.',403);return new Response(obj.body,{headers:{'Cache-Control':'no-store','Content-Type':'application/octet-stream','Content-Disposition':`attachment; filename*=UTF-8''${encodeURIComponent(obj.customMetadata?.name||'dokument')}`,'X-Content-Type-Options':'nosniff'}});}
  if(!admin(u)&&u.role!=='Prezydium')fail('Brak uprawnień do dodawania dokumentów.',403);if(config.modules.document===false)fail('Biblioteka dokumentów jest wyłączona.',403);
  const form=await req.formData(),file=form.get('file');if(!(file instanceof File)||file.size>10485760)fail('Wybierz plik do 10 MB.');const bytes=new Uint8Array(await file.arrayBuffer()),resolution=form.get('purpose')==='resolution';let mime='',pages=1;
  if(resolution){mime=new TextDecoder().decode(bytes.slice(0,5))==='%PDF-'?'application/pdf':bytes[0]===137&&bytes[1]===80&&bytes[2]===78&&bytes[3]===71?'image/png':bytes[0]===255&&bytes[1]===216&&bytes[2]===255?'image/jpeg':'';if(!mime)fail('Uchwała musi być plikiem PDF, PNG lub JPG.');pages=mime==='application/pdf'?Number(form.get('pages')):1;if(!Number.isInteger(pages)||pages<1||pages>500)fail('Nieprawidłowa liczba stron dokumentu.');}
  const key=crypto.randomUUID();await env.BUCKET.put(key,bytes,{customMetadata:{name:file.name,...(resolution?{resolution:'1',mime,pages:String(pages)}:{})}});return json({key,name:file.name,...(resolution?{attachment:{key,name:file.name,mime,pages}}:{})});
 }
 fail('Nie znaleziono zasobu.',404);
}
