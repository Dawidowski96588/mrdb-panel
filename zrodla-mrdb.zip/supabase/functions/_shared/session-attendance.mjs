export const ATTENDANCE_STATUSES=['Nie sprawdzono','Obecny','Nieobecny','Usprawiedliwiony','Spóźniony','Poza salą'];
export const ATTENDANCE_ACTIONS={present:'Obecność',absent:'Nieobecność',excused:'Usprawiedliwienie',late:'Spóźnienie',exit:'Wyjście',return:'Powrót',correction:'Korekta',close:'Zamknięcie listy',reopen:'Wznowienie listy'};
const fail=message=>{throw Object.assign(new Error(message),{status:400});};
export function sessionMembers(session){const members=session.roster.map(m=>({...m,status:'Nie sprawdzono',inside:false,everPresent:false,lastAt:null}));const byId=new Map(members.map(m=>[m.id,m]));for(const entry of session.entries||[]){const m=byId.get(entry.memberId);if(m&&entry.after)Object.assign(m,entry.after,{lastAt:entry.at});}return members;}
export function nextAttendance(current,action,status){
 const next={status:current.status,inside:current.inside,everPresent:current.everPresent};
 if(['present','late','absent','excused'].includes(action)){
  if(current.everPresent||current.inside)fail('Ta osoba ma już odnotowane przyjście. Użyj Wyjście, Powrót albo Korekta.');
  if(['present','late'].includes(action)){next.inside=true;next.everPresent=true;next.status=action==='late'?'Spóźniony':'Obecny';}
  else{next.status=action==='absent'?'Nieobecny':'Usprawiedliwiony';if(current.status===next.status)fail('Ten status jest już zapisany.');}
 }else if(action==='exit'){if(!current.inside)fail('Ta osoba nie jest obecnie na sali.');next.inside=false;next.status='Poza salą';}
 else if(action==='return'){if(current.inside||!current.everPresent)fail('Powrót odnotuj po wcześniejszym wyjściu.');next.inside=true;next.status='Obecny';}
 else if(action==='correction'){if(!ATTENDANCE_STATUSES.includes(status))fail('Wybierz poprawny status korekty.');next.status=status;next.inside=['Obecny','Spóźniony'].includes(status);next.everPresent=next.inside||status==='Poza salą';}
 else fail('Nieprawidłowa czynność obecności.');
 return next;
}
