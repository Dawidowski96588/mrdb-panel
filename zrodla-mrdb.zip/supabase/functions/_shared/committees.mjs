export const NO_COMMITTEE='Brak komisji';
export const WHOLE_COUNCIL='Cała MRDB';
export const COMMITTEE_CHAIR='Przewodniczący komisji';
export const COMMITTEE_MEMBER='Członek komisji';
export function committeeNames(configured=[]){return [...new Set(configured.filter(c=>c&&!['Prezydium','MRDB',NO_COMMITTEE,WHOLE_COUNCIL].includes(c)))];}
export function actionCommittees(configured=[],user){
 const manager=!user||['Przewodniczący','Koordynator','Prezydium'].includes(user.role);
 return [...new Set([NO_COMMITTEE,WHOLE_COUNCIL,...(manager?configured.filter(c=>c!=='MRDB'):user.profile?.committee?[user.profile.committee]:[])])];
}
